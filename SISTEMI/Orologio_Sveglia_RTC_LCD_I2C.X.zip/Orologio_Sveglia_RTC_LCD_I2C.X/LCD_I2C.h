
/*
 Definizione dell'indirizz del PCF8574 Remote 8-bit I/O Expander per I2C-bus.
 Rif. datasheet del PCF8574(A)
 */

#define PCF8574WriteMode  0b01001110   // Indirizzo del PCF8574 (0x27) + Write bit (bit LSB)


char	 LCD_BL_Status = 1;     // 1 for POSITIVE control, 0 for NEGATIVE control


char	 pin_RS;		//  I2C_BYTE.0
char	 pin_RW;		//  I2C_BYTE.1
char	 pin_E;			//  I2C_BYTE.2
char	 pin_BL;		//  I2C_BYTE.3
char	 pin_D4;		//  I2C_BYTE.4
char	 pin_D5;		//  I2C_BYTE.5
char	 pin_D6;		//  I2C_BYTE.6
char	 pin_D7;		//  I2C_BYTE.7


char LCD_crea_Byte()
{
    char I2C_BYTE = 0x00;

    I2C_BYTE |= pin_RS   << 0;
    I2C_BYTE |= pin_RW   << 1;
    I2C_BYTE |= pin_E    << 2;
    I2C_BYTE |= pin_BL   << 3;
    I2C_BYTE |= pin_D4   << 4;
    I2C_BYTE |= pin_D5   << 5;
    I2C_BYTE |= pin_D6   << 6;
    I2C_BYTE |= pin_D7   << 7;

    return I2C_BYTE;
}


void Lcd_I2C_write(char val) 		// trasmissione del dato seriale
{
    I2C_Start();                    // Start comunicazione I2C
    I2C_Write(PCF8574WriteMode);     // Connetti al PCF8574 inviando l'idirizzo + write bit
    I2C_Write(val);                // Scrivi il dato  
    I2C_Stop();                     // Stop comunicazione I2C     
}


void Lcd_I2C_Port(char a)
{
	if(a & 1)	pin_D4 = 1;
	else 	pin_D4 = 0;

	if(a & 2) 	pin_D5 = 1;    
	else	pin_D5 = 0;

	if(a & 4)	pin_D6 = 1;    
	else	pin_D6 = 0;

	if(a & 8)   pin_D7 = 1;    
	else    pin_D7 = 0;
}


void Lcd_I2C_Cmd(char cmd)
{
 //   char comando;
	
	pin_RS = 0; 	
    pin_RW = 0;
    pin_E  = 0;
    pin_BL = LCD_BL_Status;
    
    Lcd_I2C_Port (cmd);
    
//    comando=LCD_crea_Byte();
    
    Lcd_I2C_write(LCD_crea_Byte());
    pin_E = 1;    
    Lcd_I2C_write(LCD_crea_Byte());
    
    __delay_ms(4);    
    
    pin_E = 0;    
    Lcd_I2C_write(LCD_crea_Byte());	
	
}

void Lcd_Clear()             // Cancella LCD
{
	Lcd_I2C_Cmd(0);
	Lcd_I2C_Cmd(1);
}

void Lcd_Set_Cursor(char a, char b)     // Posiziona cursore
{                                       // a = riga ---  b = colonna
	char temp,z,y;
	if(a == 1)
	{
	  temp = 0x80 + b - 1;
		z = temp>>4;                // z = 4 bit piu' significativi
		y = temp & 0x0F;            // y = 4 bit meno significativi
		Lcd_I2C_Cmd(z);
		Lcd_I2C_Cmd(y);
	}
	else if(a == 2)
	{
		temp = 0xC0 + b - 1;
		z = temp>>4;
		y = temp & 0x0F;
		Lcd_I2C_Cmd(z);
		Lcd_I2C_Cmd(y);
	}
}

void Lcd_Init()
{
   Lcd_I2C_Port(0x00);
    __delay_ms(20);
   Lcd_I2C_Cmd(0x03);
	__delay_ms(5);
   Lcd_I2C_Cmd(0x03);
	__delay_ms(10);
   Lcd_I2C_Cmd(0x03);
  
   Lcd_I2C_Cmd(0x02);    //LCD pilotato con 4 linee
  
   Lcd_I2C_Cmd(0x02);
   Lcd_I2C_Cmd(0x08);
  
   Lcd_I2C_Cmd(0x00);
   //Lcd_Cmd(0x0C);
   Lcd_I2C_Cmd(0x0E);    //cursore on
  
   Lcd_I2C_Cmd(0x00);
   Lcd_I2C_Cmd(0x06);
}

void Lcd_Write_Char(char a)
{
    char x,y;         
    x = a&0x0F;        // x = 4 bit meno significativi
    y = a&0xF0;        // y = 4 bit piu' significativi
   
    pin_RS = 1;        // Invio a
    pin_RW = 0;
    pin_E  = 0;
    pin_BL = LCD_BL_Status;
    
    Lcd_I2C_Port (y>>4);    
    Lcd_I2C_write(LCD_crea_Byte());
    pin_E = 1;    
    Lcd_I2C_write(LCD_crea_Byte());
    
    pin_E = 0;    
    Lcd_I2C_write(LCD_crea_Byte());	
	
    Lcd_I2C_Port (x);    
    Lcd_I2C_write(LCD_crea_Byte());
    pin_E = 1;    
    Lcd_I2C_write(LCD_crea_Byte());
    
    pin_E = 0;    
    Lcd_I2C_write(LCD_crea_Byte());		
}


void Lcd_Write_String(char *a)
{
	int i;
	for(i=0;a[i]!='\0';i++)
	   Lcd_Write_Char(a[i]);
}


void Lcd_Shift_Right()
{
	Lcd_I2C_Cmd(0x01);
	Lcd_I2C_Cmd(0x0C);
}


void Lcd_Shift_Left()
{
	Lcd_I2C_Cmd(0x01);
	Lcd_I2C_Cmd(0x08);
}

void Lcd_Write_Val(int val) 
{
    char cent=0, dec=0, uni=0;

 //scomposizione di 'val' in unit� decine e centinaia
    
    while (val>=100) { 
        val-=100;
        cent++;
        }
    while (val>=10) {
        val-=10;
        dec++;
        }
    uni=val;
    
    if (cent==0 && dec==0) dec=32; // spengo 'dec' se 'cent' e 'dec' valgono '0'
        else dec+=48;
    
    if (cent==0) cent=32; // spengo 'cent' se vale '0'
        else cent+=48;
    
    uni+=48;
    
    Lcd_Write_Char(cent);
    Lcd_Write_Char(dec);    
    Lcd_Write_Char(uni);        
 
}


typedef struct
{
  char sec;
  char min;
  char ora;
  char weekDay;
  char giorno;
  char mese;
  char anno;  
}RTC_time;

//RTC_time orologio;

void scriviDato(char dato)
{
    char x,y;
    
    x = dato & 0x0F;
    y = (dato>>4);
    Lcd_Write_Char(y+48);
    Lcd_Write_Char(x+48);    
}


void Lcd_writeRTC(RTC_time *rtc)
{
    char a;
    Lcd_Set_Cursor(1,1);  
    Lcd_Write_String("Time:  ");    
    
    a = rtc->ora;  
    scriviDato(a);
    Lcd_Write_Char(':');
    
    a = rtc->min;  
    scriviDato(a);
    Lcd_Write_Char(':');
    
    a = rtc->sec;  
    scriviDato(a);

    Lcd_Set_Cursor(2,1);  
    Lcd_Write_String("Date:  ");     
    
    a = rtc->giorno;  
    scriviDato(a);
    Lcd_Write_Char('/');    
   
    a = rtc->mese;  
    scriviDato(a);
    Lcd_Write_Char('/'); 
    
    a = rtc->anno;  
    scriviDato(a);
    Lcd_Write_Char(' '); 
    
}

char LCD_Incremento(char v){
    int dec, uni;
    dec=(v&0xF0)>>4;
    uni=v&0x0F;
    uni++;
    if(uni>9){
        uni=0;
        dec++;
    }
    return ((dec)<<4)+(uni);
}
