/*
 * OROLOGIO SVEGLIA
 * 
 * DISPLAY LCD COLLEGATO CON I2C
 * BUZZER IN RD0
 * LED IN RD1
 * PULSANTE RA5 = PULSANTE OROLOGIO
 * PULSANTE RB0 = PULSANTE SVEGLIA
 * 
 * ALL'ACCENSIONE:
 * - TENENDO PREMUTI CONTEMPORANEAMENTE I DUE PULSANTI FINO ALLA COMPARSA DELLA SCRITTA "OROLOGIO-SVEGLIA" 
 *   SI IMPOSTANO OROLOGIO E SVEGLIA A VALORI PREDEFINITI
 * 
 * IN MODALITA' NORMALE:
 * - PREMENDO IL PULSANTE OROLOGIO PER 2 SEC. SI ENTRA IN MODALITA' PROGRAMMAZIONE OROLOGIO
 * - PREMENDO IL PULSANTE SVEGLIA PER 2 SEC. SI ENTRA IN MODALITA' PROGRAMMAZIONE SVEGLIA
 * - SE STA SUONANDO LA SVEGLIA, PREMENDO UNO DEI DUE PULSANTI SI DISATTIVA LA SVEGLIA
 * - SE NON VIENE INTERROTTA LA SVEGLIA SUONA PER 30 SEC.
 * 
 * IN MODALITA' PROGRAMMAZIONE:
 * - PREMENDO IL PULSANTE OROLOGIO SI SPOSTA IL CURSORE
 * - PREMENDO IL PULSANTE SVEGLIA SI INCREMENTA IL VALORE SELEZIONATO
 * - TENENDO PREMUTO IL PULSANTE OROLOGIO PER 2 SEC. SI ESCE SALVANDO I VALORI
 */

#pragma config FOSC = XT        // Oscillator Selection bits (XT oscillator: Crystal/resonator on RA6/OSC2/CLKOUT and RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = ON       // RE3/MCLR pin function select bit (RE3/MCLR pin function is MCLR)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.


#include <xc.h>                    //Header file generico

#define _XTAL_FREQ 8000000         //Specifico la frequenza dell'oscillatore

#include "I2C.h"
#include "LCD_I2C.h"
#include "RTC_DS1307.h"

#define secReg           0x00        // Indirizzo registro dei "secondi"
#define minReg           0x01        // Indirizzo registro dei "minuti"
#define oraReg           0x02        // Indirizzo registro dei "ore"
#define weekDayReg       0x03        // Indirizzo registro dei "giorno della settimana"
#define giornoReg        0x04        // Indirizzo registro "giorno"
#define meseReg          0x05        // Indirizzo registro dei "mese"
#define annoReg          0x06        // Indirizzo registro dei "anno"


int prog=0, sveglia=0, suona=0;

void main(void) {

    PORTA = 0x00;
    PORTB = 0x00;    
    PORTC = 0x00;
    PORTD = 0x00;    
    PORTE = 0x00;   

    TRISA = 0b00100011;             //Imposto tutti i pin di PORTA come output
    TRISB = 0b00000001;             //Imposto tutti i pin di PORTB come output
    TRISC = 0b00011000;             //Imposto input RC3=SCL e RC4=SDA
    TRISD = 0b00000000;             //Imposto tutti i pin di PORTD come output
    TRISE = 0b11111111;             //Imposto tutti i pin di PORTE come input
    
    ANSEL = 0x00;                   //Imposto tutti i pin come ingressi digitali
    ANSELH = 0x00;                  //Imposto tutti i pin come ingressi digitali
    
    I2C_Init();
    Lcd_Init();
    
 
    RTC_time rtc;                  // Dichiarazione di una struttura "rtc"
    RTC_time rtcs;
    
    RTC_Init();
    
  // Nel DS1307 data e ora vengono memorizzati in formato BCD
    
    rtc.ora = 0x11; //  12:30:00 am
    rtc.min = 0x30;
    rtc.sec = 0x00;

    rtc.giorno = 0x31; // 1 gennaio 2018
    rtc.mese = 0x01;
    rtc.anno = 0x18;
    rtc.weekDay = 0x01; // luned�
    
    rtcs.ora = 0x12; //  12:30:00 am
    rtcs.min = 0x30;
    rtcs.sec = 0x00;

    rtcs.giorno = 0x01; // 1 gennaio 2018
    rtcs.mese = 0x31;
    rtcs.anno = 0x18;
    rtcs.weekDay = 0x01; // luned�
  
    //se i pulsanti sono premuti resetto l'ora
    if(RA5==0&&RB0==0){
        RTC_writeTC(&rtc);  // Scrivi ora e data nell'RTC DS1307p
        RTC_writeTCS_EE(&rtcs);  // Scrivi ora e data nell'RTC DS1307
    }
    
    
        /*Lcd_Clear();
        Lcd_Set_Cursor(1,3);
        Lcd_Write_String("IS \"Galilei\"");
        Lcd_Set_Cursor(2,4);
        Lcd_Write_String("CONEGLIANO");
        
        __delay_ms(2000);*/
    
        Lcd_Clear();
        Lcd_Set_Cursor(1,1);
        Lcd_Write_String("OROLOGIO-SVEGLIA");
        
        __delay_ms(2000);   
        Lcd_Clear();        
    
    /* visualizza continuamente ora e data*/
    while(1)
    {
        
        RTC_readTC(&rtc); // leggi ora e data dall'RTC DS1307
        RTC_readTCS_EE(&rtcs); // leggi ora e data dall'RTC DS1307
        Lcd_Set_Cursor(2,0);
        Lcd_writeRTC(&rtc);
        
        
        
        //sveglia
        if(rtc.ora==rtcs.ora && rtc.min==rtcs.min && rtc.sec<30){
            if(suona==1) suona=2;
        }
        else{
            suona=1;
        }
        
        if(suona==2){
            RD0^=1;//buzzer
            RD1^=1;//led
        }
        else{
            RD0=0;//buzzer
            RD1=0;//led
        }
        
        //programmazione
        if(RB0==0){
            suona=0;
            prog++;
            sveglia=0;
        }
        else{
            prog=0;
        }
        
        //sveglia
        if(RA5==0){
            suona=0;
            sveglia++;
            prog=0;
        }
        else{
            sveglia=0;
        }

        //modalit� programmazione
        if(prog>10){
            prog=0;
            Lcd_Clear();
            Lcd_Set_Cursor(1,5);
            Lcd_Write_String("MODALITA'");
            Lcd_Set_Cursor(2,2);
            Lcd_Write_String("PROGRAMMAZIONE ");
            __delay_ms(2000);

            Lcd_Clear();

            int index=1;
            int exit=0;
            while(1){
                Lcd_writeRTC(&rtc);
                char v;
                switch(index){
                    case 1:
                        v=rtc.ora;
                        Lcd_Set_Cursor(1,9);
                        break;
                    case 2:
                        v=rtc.min;
                        Lcd_Set_Cursor(1,12);
                        break;
                    case 3:
                        v=rtc.sec;
                        Lcd_Set_Cursor(1,15);
                        break;
                    case 4:
                        v=rtc.giorno;
                        Lcd_Set_Cursor(2,9);
                        break;
                    case 5:
                        v=rtc.mese;
                        Lcd_Set_Cursor(2,12);
                        break;
                    case 6:
                        v=rtc.anno;
                        Lcd_Set_Cursor(2,15);
                        break;
                }
                //incremento valore
                if(RA5==0){
                    v=LCD_Incremento(v);
                
                    switch(index){
                        case 1:
                            if(v>0x23) v=0;
                            rtc.ora=v;
                            break;
                        case 2:
                            if(v>0x59) v=0;
                            rtc.min=v;
                            break;
                        case 3:
                            if(v>0x59) v=0;
                            rtc.sec=v;
                            break;
                        case 4:
                            if(v>0x31) v=1;
                            rtc.giorno=v;
                            break;
                        case 5:
                            if(v>0x12) v=1;
                            rtc.mese=v;
                            break;
                        case 6:
                            if(v>0x99) v=0;
                            rtc.anno=v;
                            break;
                    }
                }
                //aumento indice
                if(RB0==0){
                    index++;
                    if(index>6) index=1;
                    exit++;
                }
                else{
                    exit=0;
                }
                //uscire
                if(exit>20) break;

                __delay_ms(100);
                
            }//while

            RTC_writeTC(&rtc);
            Lcd_Clear();
            Lcd_Set_Cursor(1,4);
            Lcd_Write_String("SALVATAGGIO ");
            Lcd_Set_Cursor(2,2);
            Lcd_Write_String("");
            while(RB0==0){};
        }
        
        //modalit� sveglia
        if(sveglia>10){
            prog=0;
            Lcd_Clear();
            Lcd_Set_Cursor(1,5);
            Lcd_Write_String("MODALITA'");
            Lcd_Set_Cursor(2,6);
            Lcd_Write_String("SVEGLIA");
            __delay_ms(2000);

            Lcd_Clear();

            int index=1;
            int exit=0;
            while(1){
                Lcd_writeRTC(&rtcs);
                char v;
                switch(index){
                    case 1:
                        v=rtcs.ora;
                        Lcd_Set_Cursor(1,9);
                        break;
                    case 2:
                        v=rtcs.min;
                        Lcd_Set_Cursor(1,12);
                        break;
                    case 3:
                        v=rtcs.sec;
                        Lcd_Set_Cursor(1,15);
                        break;
                    case 4:
                        v=rtcs.giorno;
                        Lcd_Set_Cursor(2,9);
                        break;
                    case 5:
                        v=rtcs.mese;
                        Lcd_Set_Cursor(2,12);
                        break;
                    case 6:
                        v=rtcs.anno;
                        Lcd_Set_Cursor(2,15);
                        break;
                }
                //incremento valore
                if(RA5==0){
                    v=LCD_Incremento(v);
                
                    switch(index){
                        case 1:
                            if(v>0x23) v=0;
                            rtcs.ora=v;
                            break;
                        case 2:
                            if(v>0x59) v=0;
                            rtcs.min=v;
                            break;
                        case 3:
                            if(v>0x59) v=0;
                            rtcs.sec=v;
                            break;
                        case 4:
                            if(v>0x31) v=1;
                            rtcs.giorno=v;
                            break;
                        case 5:
                            if(v>0x12) v=1;
                            rtcs.mese=v;
                            break;
                        case 6:
                            if(v>0x99) v=0;
                            rtcs.anno=v;
                            break;
                    }
                }
                //aumento indice
                if(RB0==0){
                    index++;
                    if(index>6) index=1;
                    exit++;
                }
                else{
                    exit=0;
                }
                //uscire
                if(exit>20) break;

                __delay_ms(100);
                
            }//while

            //salvaggio su memoria
            RTC_writeTCS_EE(&rtcs);
            Lcd_Clear();
            Lcd_Set_Cursor(1,4);
            Lcd_Write_String("SALVATAGGIO ");
            Lcd_Set_Cursor(2,2);
            Lcd_Write_String("");
            while(RB0==0){};
        }
        
        __delay_ms(200);
    }


}

