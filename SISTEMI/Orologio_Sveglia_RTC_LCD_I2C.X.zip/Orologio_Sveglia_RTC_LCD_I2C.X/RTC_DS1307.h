
/*
 Definizione della modalit� di funzionamento e degli indirizzi dei registri del DS1307.
 Rif. datasheet del DS1307
 */

#define DS1307ReadMode   0b11010001   // Indirizzo del DS1307 (1101000) + Read bit (bit LSB)
#define DS1307WriteMode  0b11010000   // Indirizzo del DS1307 (1101000) + Write bit (bit LSB)
#define EEPROM_RTC_Read  0b10100001   // Indirizzo del AT24C32 (1010000) + Read bit (bit LSB)
#define EEPROM_RTC_Write 0b10100000   // Indirizzo del AT24C32 (1010000) + Write bit (bit LSB)

#define secReg           0x00         // Indirizzo registro dei "secondi"
#define minReg           0x01         // Indirizzo registro dei "minuti"
#define oraReg           0x02         // Indirizzo registro dei "ore"
#define dayReg           0x03         // Indirizzo registro dei "giorno della settimana"
#define giornoReg        0x04         // Indirizzo registro "giorno"
#define meseReg          0x05         // Indirizzo registro dei "mese"
#define annoReg          0x06         // Indirizzo registro dei "anno"
#define controlReg       0x07         // Indirizzo del ControlRegister

#define memReg           0x10    

char valore;

// Definizione della struttura RTC_time mantenendo l'ordine dei registri interni al DS1307
typedef struct
{
  char sec;
  char min;
  char ora;
  char weekDay;
  char giorno;
  char mese;
  char anno;  
}RTC_time;



void RTC_Init(void)
{                               
    I2C_Start();                       // Start comunicazione I2C

    I2C_Write(DS1307WriteMode);        // Connetti al DS1307 inviando l'idirizzo + write bit
    I2C_Write(controlReg);             // Punta al ControlRegister (invia indirizzo 0x07) 

    I2C_Write(0x00);                   // Scrivi 0x00 nel ControlRegister per disabilitare SQW/OUT

    I2C_Stop();                        // Stop I2C communication after initializing DS1307
}


// Scrivi data e time
void RTC_writeTC(RTC_time *rtc)
{
    I2C_Start();                       // Start comunicazione I2C

    I2C_Write(DS1307WriteMode);        // Connetti al DS1307 inviando l'idirizzo + write bit
    I2C_Write(secReg);                 // Punta al registro secondi (invia indirizzo 0x00)
                                       // L'incremento del puntatore � automatico

    I2C_Write(rtc->sec);               // Scrivi i secondi nella RAM all'indirizzo 00H
    I2C_Write(rtc->min);               // Scrivi i minuti nella RAM all'indirizzo 01H
    I2C_Write(rtc->ora);               // Scrivi le ore nella RAM all'indirizzo 02H
    I2C_Write(rtc->weekDay);           // Scrivi giorno settimana nella RAM all'indirizzo 03H
    I2C_Write(rtc->giorno);            // Write date on RAM address 04H
    I2C_Write(rtc->mese);              // Write month on RAM address 05H
    I2C_Write(rtc->anno);              // Write year on RAM address 06h

    I2C_Stop();                        // Stop comunicazione I2C 
}

// Scrivi data e time
void RTC_writeTCS(RTC_time *rtc)
{
    I2C_Start();                       // Start comunicazione I2C

    I2C_Write(DS1307WriteMode);        // Connetti al DS1307 inviando l'idirizzo + write bit
    I2C_Write(memReg);                 // Punta al registro secondi (invia indirizzo 0x00)
                                       // L'incremento del puntatore � automatico

    I2C_Write(rtc->sec);               // Scrivi i secondi nella RAM all'indirizzo 00H
    I2C_Write(rtc->min);               // Scrivi i minuti nella RAM all'indirizzo 01H
    I2C_Write(rtc->ora);               // Scrivi le ore nella RAM all'indirizzo 02H
    I2C_Write(rtc->weekDay);           // Scrivi giorno settimana nella RAM all'indirizzo 03H
    I2C_Write(rtc->giorno);            // Write date on RAM address 04H
    I2C_Write(rtc->mese);              // Write month on RAM address 05H
    I2C_Write(rtc->anno);              // Write year on RAM address 06h

    I2C_Stop();                        // Stop comunicazione I2C 
}
// Scrivi data e time
void RTC_writeTCS_EE(RTC_time *rtc)
{
    I2C_Start();                       // Start comunicazione I2C

    I2C_Write(EEPROM_RTC_Write);        // Connetti al DS1307 inviando l'idirizzo + write bit
    I2C_Write(0x00);
    I2C_Write(memReg);                 
                                       

    I2C_Write(rtc->sec);               // Scrivi i secondi nella RAM all'indirizzo 00H
    I2C_Write(rtc->min);               // Scrivi i minuti nella RAM all'indirizzo 01H
    I2C_Write(rtc->ora);               // Scrivi le ore nella RAM all'indirizzo 02H
    I2C_Write(rtc->weekDay);           // Scrivi giorno settimana nella RAM all'indirizzo 03H
    I2C_Write(rtc->giorno);            // Write date on RAM address 04H
    I2C_Write(rtc->mese);              // Write month on RAM address 05H
    I2C_Write(rtc->anno);              // Write year on RAM address 06h

    I2C_Stop();                        // Stop comunicazione I2C 
}


// Leggi data e time
void RTC_readTC(RTC_time *rtc)
{
    I2C_Start();                       // Start comunicazione I2C

    I2C_Write(DS1307WriteMode);        // Connetti al DS1307 inviando l'idirizzo + write bit
    I2C_Write(secReg);                 // Punta al registro secondi (invia indirizzo 0x00)
                                       
    I2C_Stop();                        // Stop comunicazione I2C

    I2C_Start();                       // Start comunicazione I2C
    I2C_Write(DS1307ReadMode);         // Connetti al DS1307 inviando l'idirizzo + read bit

    rtc->sec = I2C_Read(1);            // Leggi i secindi e invia un Positive ACK
    rtc->min = I2C_Read(1);            // Leggi i minuti e invia un Positive ACK
    rtc->ora= I2C_Read(1);             // Leggi l'ora e invia un Positive ACK
    rtc->weekDay = I2C_Read(1);        // Leggi il weeDay e invia un Positive ACK
    rtc->giorno= I2C_Read(1);          // Leggi il giorno e invia un Positive ACK
    rtc->mese=I2C_Read(1);             // Leggi il mese e invia un Positive ACK
    rtc->anno =I2C_Read(0);            // Leggi l'anno e invia un Negative ACK

    I2C_Stop();                        // Stop comunicazione I2C
}


// Leggi data e time
void RTC_readTCS(RTC_time *rtcs)
{
    I2C_Start();                       // Start comunicazione I2C

    I2C_Write(DS1307WriteMode);        // Connetti al DS1307 inviando l'idirizzo + write bit
    I2C_Write(memReg);                 // Punta al registro secondi (invia indirizzo 0x00)
                                       
    I2C_Stop();                        // Stop comunicazione I2C

    I2C_Start();                       // Start comunicazione I2C
    I2C_Write(DS1307ReadMode);         // Connetti al DS1307 inviando l'idirizzo + read bit

    rtcs->sec = I2C_Read(1);            // Leggi i secindi e invia un Positive ACK
    rtcs->min = I2C_Read(1);            // Leggi i minuti e invia un Positive ACK
    rtcs->ora= I2C_Read(1);             // Leggi l'ora e invia un Positive ACK
    rtcs->weekDay = I2C_Read(1);        // Leggi il weeDay e invia un Positive ACK
    rtcs->giorno= I2C_Read(1);          // Leggi il giorno e invia un Positive ACK
    rtcs->mese=I2C_Read(1);             // Leggi il mese e invia un Positive ACK
    rtcs->anno =I2C_Read(0);            // Leggi l'anno e invia un Negative ACK

    I2C_Stop();                        // Stop comunicazione I2C
}

// Leggi data e time
void RTC_readTCS_EE(RTC_time *rtcs)
{
    I2C_Start();                       // Start comunicazione I2C

    I2C_Write(EEPROM_RTC_Write);        // Connetti al DS1307 inviando l'indirizzo + write bit
    I2C_Write(0x00);
    I2C_Write(memReg);                 
                                       
    I2C_Stop();                        // Stop comunicazione I2C

    I2C_Start();                       // Start comunicazione I2C
    I2C_Write(EEPROM_RTC_Read);         // Connetti al DS1307 inviando l'idirizzo + read bit

    rtcs->sec = I2C_Read(1);            // Leggi i secindi e invia un Positive ACK
    rtcs->min = I2C_Read(1);            // Leggi i minuti e invia un Positive ACK
    rtcs->ora= I2C_Read(1);             // Leggi l'ora e invia un Positive ACK
    rtcs->weekDay = I2C_Read(1);        // Leggi il weeDay e invia un Positive ACK
    rtcs->giorno= I2C_Read(1);          // Leggi il giorno e invia un Positive ACK
    rtcs->mese=I2C_Read(1);             // Leggi il mese e invia un Positive ACK
    rtcs->anno =I2C_Read(0);            // Leggi l'anno e invia un Negative ACK

    I2C_Stop();                        // Stop comunicazione I2C
}

//scrivi su un registro
void RTC_Set(char ind, char dato)
{
        I2C_Start();                    // Start comunicazione I2C
        I2C_Write(DS1307WriteMode);     // Connetti al DS1307 inviando l'idirizzo + write bit
        I2C_Write(ind);                 // Punta all'indirizzo del registro prescelto
        I2C_Write(dato);                // Scrivi il dato  
        I2C_Stop();                     // Stop comunicazione I2C     
}


// Leggi da un registro
char RTC_read(char ind)
{
    I2C_Start();                       // Start comunicazione I2C

    I2C_Write(DS1307WriteMode);        // Connetti al DS1307 inviando l'idirizzo + write bit
    I2C_Write(ind);                    // Punta al registro 
                                       
    I2C_Stop();                        // Stop comunicazione I2C

    I2C_Start();                       // Start comunicazione I2C
    I2C_Write(DS1307ReadMode);         // Connetti al DS1307 inviando l'idirizzo + read bit

    valore = I2C_Read(0);              // Leggi e invia un Negative ACK

    I2C_Stop();                        // Stop comunicazione I2C
    
    return valore; 
}



