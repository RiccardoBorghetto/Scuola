/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package client;
import java.io.*;
import java.util.Scanner;


/**
 *
 * @author Riccardo
 */
public class FileTesto {
    
    private FileWriter writer;
    private PrintWriter fout;
    
    private FileReader reader;
    private Scanner fin;
    
    
    
    
    public boolean openForWrite(String nomefile, boolean modo){
       try{
        writer = new FileWriter(nomefile, modo);
        fout = new PrintWriter(writer);
        return true;
       }
       catch(IOException e){
           return false;
       }
     
    }
    
    public boolean openForRead(String nomefile){
       try{
        reader = new FileReader(nomefile);
        fin = new Scanner(reader);
        return true;
       }
       catch(IOException e){
           return false;
       }
    }
    
    
    
    
    public boolean closeFileWrite(){
        try {
            fout.close();
            writer.close();
            return true;
        } catch (IOException ex) {
            return false;
         }
    }
    
    public boolean closeFileRead(){
        try {
            fin.close();
            reader.close();
            return true;
        } catch (IOException ex) {
            return false;
         }
    }
    
    
    
    public boolean scriviRiga(String riga){
        fout.println(riga);
        return true;
    }
    
    public String leggiRiga(){
        if(fin.hasNextLine()){
            return (fin.nextLine());
        }
        else
            return "";
    }
    
    
    
    
    public FileTesto(){
      
  }  
    
}
