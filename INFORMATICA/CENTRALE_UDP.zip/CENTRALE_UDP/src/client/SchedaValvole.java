/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

/**
 *
 * @author Riccardo 
 */
public class SchedaValvole {
 String ip;
 int  porta;
 String uscite;
 int num_msg;
 int num_err;
 boolean enable;
 
 
 SchedaValvole(String ip, int porta)
    {
    this.ip=ip;
    this.porta=porta;
    uscite="0000";
    num_msg=0;
    num_err=0;
    }
    
}
