/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;
import client.SchedaValvole;
import client.Termostato;
import client.FileTesto;
import java.util.Timer;
import java.util.TimerTask;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

//import java.util.*;
import java.io.*;
import java.net.*;
import java.util.Locale;




/**
 *
 * @author Riccardo
 */
public class MainForm extends javax.swing.JFrame {
    
    String Uscite_Valvole;
    String Ev1="0";
    String Ev2="0";
    String Ev3="0";
    String Ev4="0";
    Termostato[] termostati;
    SchedaValvole[] schValvole;
    int contaT;
    
    String[] token;
    
    byte[] mittAddr;
    byte[] destAddr;
    DatagramSocket socket ;
    byte[] buf_rx = new byte[256];
    byte[] buf_tx = new byte[256];
    String payload_rx;
    String payload_tx;
    DatagramPacket packet_rx;
    DatagramPacket packet_tx;
    InetAddress mit_address;
    
    int mit_port;
    int mia_porta;
    InetAddress dest_address;
    int dest_port;
    
     int ClientState=0 ;
     int ClientSTART=0 ;
     int x=0;
     int r=0;
     
    byte buffer[];
    byte[] buffer1;
    
    
    //-----------------------------------------------------------
       
    Timer Timer_01=new Timer();     // dichiara ed istanzia Oggetto Timer
    Timer Timer_02=new Timer();
    
    
     /**
     * Creates new form MainForm
     */
    public MainForm() {
        
        
       
        termostati = new Termostato[4];
        termostati[0] = new Termostato("127.0.0.1", 4444);
        termostati[1] = new Termostato("127.0.0.1", 4445);
        termostati[2] = new Termostato("127.0.0.1", 4446);
        termostati[3] = new Termostato("127.0.0.1", 4447);
        
        
        schValvole = new SchedaValvole[4];
        schValvole[0]=new SchedaValvole("127.0.0.1", 4450);
        //schValvole[1]=new SchedaValvole("127.0.0.1", 4451);
        //schValvole[2]=new SchedaValvole("127.0.0.1", 4452);
        //schValvole[3]=new SchedaValvole("127.0.0.1", 4453);
        
        
        contaT=0;
        schValvole[0].uscite="0000";
       
        initComponents();
        Timer_01.schedule(new Timer_01_Task(), 100, 100);
        Timer_02.schedule(new Timer_02_Task(), 100, Integer.parseInt(Delay.getText()));
        
        
        
        
    }

   
    
    
    class Timer_01_Task extends TimerTask{
        @Override
        public void run(){
        Termostati_SchedaValvole();  // gestisce schede termostati
        TermoRegolazione();          // gestione  scheda valvole
        }
    }
    
    class Timer_02_Task extends TimerTask{
        @Override
        public void run(){
            
        if(x==1){    
        SalvaSuFile();
        }
        
        }
    }
    
    public void ApriValv(){
    
        FileTesto R1 = new FileTesto();
        
        R1.openForRead("ip.txt");
        
        
        String r1;
        
        r1 = R1.leggiRiga();
        
        
    
    
    }
    
    
    public void SalvaSuFile(){
        
        FileTesto T1 = new FileTesto();
        T1.openForWrite("Log.csv", true);
        if(r==0){
            T1.scriviRiga(DateTimeFormatter.ofPattern("ddMMyyyy hh:mm:ss").format(LocalDateTime.now()) + ";" + "TrilT1" + ";" + "TsetT1" + ";" + "TrilT2" + ";" + "TsetT2" + ";" + "TrilT3" + ";" + "TsetT3" + ";" + "TrilT4" + ";" + "TsetT4");
            T1.scriviRiga(DateTimeFormatter.ofPattern("ddMMyyyy hh:mm:ss").format(LocalDateTime.now()) + ";" + " " + ";" + " " + ";" + " " + ";" + " " + ";" + " " + ";" + " " + ";" + " " + ";" + " ");
            r=1;
        }
        T1.scriviRiga(DateTimeFormatter.ofPattern("ddMMyyyy hh:mm:ss").format(LocalDateTime.now()) + ";" + TrilT1.getText() + ";" + TsetT1.getText() + ";" + TrilT2.getText() + ";" +TsetT2.getText() + ";" + TrilT3.getText() + ";" +TsetT3.getText() + ";" + TrilT4.getText() + ";" +TsetT4.getText());
        T1.closeFileWrite();
    
    } 
    
    
    
    
    public void	TermoRegolazione() {
      
       //  regolazione STANZA 1
       if(termostati[0].temperaturaRIL> termostati[0].temperaturaSET+10 ) 
           Ev1="0";
       if(termostati[0].temperaturaRIL< termostati[0].temperaturaSET-10 ) 
           Ev1="1";
       
       // regolazione stanza 2 
       if(termostati[1].temperaturaRIL< termostati[0].temperaturaSET-10 ) 
           Ev2="0";
       if(termostati[1].temperaturaRIL< termostati[0].temperaturaSET-10 ) 
           Ev2="1";
       //regolazione stanza 3
       if(termostati[2].temperaturaRIL< termostati[0].temperaturaSET-10 ) 
           Ev3="0";
       if(termostati[2].temperaturaRIL< termostati[0].temperaturaSET-10 ) 
           Ev3="1";
       //regolazione stanza 4
       if(termostati[3].temperaturaRIL< termostati[0].temperaturaSET-10 ) 
           Ev4="0";
       if(termostati[3].temperaturaRIL< termostati[0].temperaturaSET-10 ) 
           Ev4="1";
       
       schValvole[0].uscite=Ev1+Ev2+Ev3+Ev4;
        
    }

    
 /**
 * Metodo per generare una rampa digitale sull'uscita del DAC 
 * presente nel SERVER 
 * 
 * 
 * 
 * 
 */    
  
 
    
 public	void	Termostati_SchedaValvole() {
    switch(ClientState) 
        {
        // FASE 0:   attesa di  avere lo START per aprire il SOCKET 
        case 0:
            if(ClientSTART==0)
                break;
            try{
                mia_porta= Integer.parseInt(PORTA.getText());
                socket = new DatagramSocket(mia_porta);
                packet_rx  = new DatagramPacket(buf_rx, buf_rx.length);
                packet_tx  = new DatagramPacket(buf_tx, buf_tx.length);
                System.out.println("SOCKET APERTO \n" );
                }
            catch(Exception e) { System.out.println("ERRORE APERTURA SOCKET \n" );}
            ClientState=1;
            contaT=0;
            break;
        // lettura sonde temperatura di tutti i termostati       
        case 1:
                payload_tx="READ:";
                buf_tx = payload_tx.getBytes(); // converte la stringa in byte 
                packet_tx.setData(buf_tx);
                packet_tx.setPort(termostati[contaT].porta);
                try{
                   dest_address=InetAddress.getByName(termostati[contaT].ip);
                   packet_tx.setAddress(dest_address);
                   socket.send(packet_tx);
                   termostati[contaT].num_msg++;
                   System.out.println("TRASMESSO\n" );
                   }
                catch(IOException e){System.out.println("ERRORE TX \n" );}
                
                try{
                    packet_rx = new DatagramPacket(buf_rx, buf_rx.length);
                    socket.setSoTimeout(30);  // setta un Timeout
                    socket.receive(packet_rx);
                    mit_address = packet_rx.getAddress();
                    mit_port = packet_rx.getPort();
                    payload_rx  = new String(packet_rx.getData(), 0, packet_rx.getLength());
                    
                    // analizza la risposta che è del tipo
                    //   "SONDA:100:SET:50" 
                    token=payload_rx.split(":");
                    termostati[contaT].temperaturaSET = Integer.parseInt(token[3]);
                    termostati[contaT].temperaturaRIL = Integer.parseInt(token[1]);
                    VisualizzaTermostato(contaT);
                    
                    // stampa su console quanto ricevuto  
                    System.out.println("RICEVUTO:" + payload_rx + "\n" );
                    System.out.println("IP:" + mit_address +  "\n" );
                    System.out.println("PORT:" + mit_port +  "\n" );
                    }
                 catch(IOException e){
                    System.out.println("NESSUNA RISPOSTA\n" ); 
                    termostati[contaT].num_err++;
                    }
                contaT++;
                if(contaT>1)
                    {contaT=1;ClientState=2;}
                break;
                
                
                case 2:
                payload_tx="READ:";
                buf_tx = payload_tx.getBytes(); // converte la stringa in byte 
                packet_tx.setData(buf_tx);
                packet_tx.setPort(termostati[contaT].porta);
                try{
                   dest_address=InetAddress.getByName(termostati[contaT].ip);
                   packet_tx.setAddress(dest_address);
                   socket.send(packet_tx);
                   termostati[contaT].num_msg++;
                   System.out.println("TRASMESSO\n" );
                   }
                catch(IOException e){System.out.println("ERRORE TX \n" );}
                
                try{
                    packet_rx = new DatagramPacket(buf_rx, buf_rx.length);
                    socket.setSoTimeout(30);  // setta un Timeout
                    socket.receive(packet_rx);
                    mit_address = packet_rx.getAddress();
                    mit_port = packet_rx.getPort();
                    payload_rx  = new String(packet_rx.getData(), 0, packet_rx.getLength());
                    
                    // analizza la risposta che è del tipo
                    //   "SONDA:100:SET:50" 
                    token=payload_rx.split(":");
                    termostati[contaT].temperaturaSET = Integer.parseInt(token[3]);
                    termostati[contaT].temperaturaRIL = Integer.parseInt(token[1]);
                    VisualizzaTermostato(contaT);
                    
                    // stampa su console quanto ricevuto  
                    System.out.println("RICEVUTO:" + payload_rx + "\n" );
                    System.out.println("IP:" + mit_address +  "\n" );
                    System.out.println("PORT:" + mit_port +  "\n" );
                    }
                 catch(IOException e){
                    System.out.println("NESSUNA RISPOSTA\n" ); 
                    termostati[contaT].num_err++;
                    }
                contaT++;
                if(contaT>1)
                    {contaT=2;ClientState=3;}
                break;
                
                case 3:
                payload_tx="READ:";
                buf_tx = payload_tx.getBytes(); // converte la stringa in byte 
                packet_tx.setData(buf_tx);
                packet_tx.setPort(termostati[contaT].porta);
                try{
                   dest_address=InetAddress.getByName(termostati[contaT].ip);
                   packet_tx.setAddress(dest_address);
                   socket.send(packet_tx);
                   termostati[contaT].num_msg++;
                   System.out.println("TRASMESSO\n" );
                   }
                catch(IOException e){System.out.println("ERRORE TX \n" );}
                
                try{
                    packet_rx = new DatagramPacket(buf_rx, buf_rx.length);
                    socket.setSoTimeout(30);  // setta un Timeout
                    socket.receive(packet_rx);
                    mit_address = packet_rx.getAddress();
                    mit_port = packet_rx.getPort();
                    payload_rx  = new String(packet_rx.getData(), 0, packet_rx.getLength());
                    
                    // analizza la risposta che è del tipo
                    //   "SONDA:100:SET:50" 
                    token=payload_rx.split(":");
                    termostati[contaT].temperaturaSET = Integer.parseInt(token[3]);
                    termostati[contaT].temperaturaRIL = Integer.parseInt(token[1]);
                    VisualizzaTermostato(contaT);
                    
                    // stampa su console quanto ricevuto  
                    System.out.println("RICEVUTO:" + payload_rx + "\n" );
                    System.out.println("IP:" + mit_address +  "\n" );
                    System.out.println("PORT:" + mit_port +  "\n" );
                    }
                 catch(IOException e){
                    System.out.println("NESSUNA RISPOSTA\n" ); 
                    termostati[contaT].num_err++;
                    }
                contaT++;
                if(contaT>1)
                    {contaT=3;ClientState=4;}
                break;
                
                case 4:
                payload_tx="READ:";
                buf_tx = payload_tx.getBytes(); // converte la stringa in byte 
                packet_tx.setData(buf_tx);
                packet_tx.setPort(termostati[contaT].porta);
                try{
                   dest_address=InetAddress.getByName(termostati[contaT].ip);
                   packet_tx.setAddress(dest_address);
                   socket.send(packet_tx);
                   termostati[contaT].num_msg++;
                   System.out.println("TRASMESSO\n" );
                   }
                catch(IOException e){System.out.println("ERRORE TX \n" );}
                
                try{
                    packet_rx = new DatagramPacket(buf_rx, buf_rx.length);
                    socket.setSoTimeout(30);  // setta un Timeout
                    socket.receive(packet_rx);
                    mit_address = packet_rx.getAddress();
                    mit_port = packet_rx.getPort();
                    payload_rx  = new String(packet_rx.getData(), 0, packet_rx.getLength());
                    
                    // analizza la risposta che è del tipo
                    //   "SONDA:100:SET:50" 
                    token=payload_rx.split(":");
                    termostati[contaT].temperaturaSET = Integer.parseInt(token[3]);
                    termostati[contaT].temperaturaRIL = Integer.parseInt(token[1]);
                    VisualizzaTermostato(contaT);
                    
                    // stampa su console quanto ricevuto  
                    System.out.println("RICEVUTO:" + payload_rx + "\n" );
                    System.out.println("IP:" + mit_address +  "\n" );
                    System.out.println("PORT:" + mit_port +  "\n" );
                    }
                 catch(IOException e){
                    System.out.println("NESSUNA RISPOSTA\n" ); 
                    termostati[contaT].num_err++;
                    }
                contaT++;
                if(contaT>1)
                    {contaT=0;ClientState=5;}
                break;
                
                
        case 5:
                payload_tx="OUT:" + schValvole[0].uscite ;
                buf_tx = payload_tx.getBytes();
                packet_tx.setData(buf_tx);
                packet_tx.setPort(schValvole[0].porta);
                try{
                   dest_address=InetAddress.getByName(schValvole[0].ip);
                   packet_tx.setAddress(dest_address);
                   socket.send(packet_tx);
                   termostati[contaT].num_msg++;
                   System.out.println("TRASMESSO\n" );
                   }
                catch(IOException e){System.out.println("ERRORE TX \n" );}
                
                try{
                    packet_rx = new DatagramPacket(buf_rx, buf_rx.length);
                    socket.setSoTimeout(30);  // setta un Timeout
                    socket.receive(packet_rx);
                    mit_address = packet_rx.getAddress();
                    mit_port = packet_rx.getPort();
                    payload_rx  = new String(packet_rx.getData(), 0, packet_rx.getLength());
                    token=payload_rx.split(":");
                   
          
                    System.out.println("RICEVUTO:" + payload_rx + "\n" );
                    System.out.println("IP:" + mit_address +  "\n" );
                    System.out.println("PORT:" + mit_port +  "\n" );
                    }
                 catch(IOException e){
                    System.out.println("NESSUNA RISPOSTA\n" ); 
                    }
                 ClientState=1;
                break;
         
            }// fine switch
      }   
    
    
    
    
 /**
  * 
  * 
  * @param riga
  * 
  *  metodo per la gestione/decodifica dei messaggi di risposta del SERVER
  * 
  * (  DA COMPLETARE ..........)
  * 
  */ 
 private void VisualizzaTermostato(int T)
    {
    switch(T)
        {
        case 0:
            TsetT1.setText(""+termostati[0].temperaturaSET);
            TrilT1.setText(""+termostati[0].temperaturaRIL);
            break;
        case 1:
            TsetT2.setText(""+termostati[1].temperaturaSET);
            TrilT2.setText(""+termostati[1].temperaturaRIL);
            break;
        case 2:
            TsetT3.setText(""+termostati[2].temperaturaSET);
            TrilT3.setText(""+termostati[2].temperaturaRIL);
            break;
        case 3:
            TsetT4.setText(""+termostati[3].temperaturaSET);
            TrilT4.setText(""+termostati[3].temperaturaRIL);
            break;
        default:
            break;
        
        }
   
      }
         
                  
          
            
            
            
            
            
   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        Text1 = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        btnClearTx = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        PORTA = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        TsetT2 = new javax.swing.JTextField();
        TrilT1 = new javax.swing.JTextField();
        TsetT1 = new javax.swing.JTextField();
        TrilT2 = new javax.swing.JTextField();
        T1E = new javax.swing.JCheckBox();
        T1E1 = new javax.swing.JCheckBox();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        Delay = new javax.swing.JTextField();
        jButton6 = new javax.swing.JButton();
        TsetT4 = new javax.swing.JTextField();
        TrilT3 = new javax.swing.JTextField();
        TsetT3 = new javax.swing.JTextField();
        TrilT4 = new javax.swing.JTextField();
        T1E2 = new javax.swing.JCheckBox();
        T1E3 = new javax.swing.JCheckBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Centrale_Termoregolazione_UDP");

        Text1.setColumns(20);
        Text1.setRows(5);
        Text1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                Text1KeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(Text1);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 10)); // NOI18N
        jLabel1.setText("CLIENT STATE");

        btnClearTx.setText("Clear");
        btnClearTx.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearTxActionPerformed(evt);
            }
        });

        jButton1.setText("CONNETTI");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        PORTA.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        PORTA.setText("9990");

        jLabel4.setText("Porta");

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setText("Scheda Valvole");

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setText("T. Impostata");

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel10.setText("T. Rilevata");

        TsetT2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        TsetT2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TsetT2ActionPerformed(evt);
            }
        });

        TrilT1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        TrilT1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TrilT1ActionPerformed(evt);
            }
        });

        TsetT1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        TsetT1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TsetT1ActionPerformed(evt);
            }
        });

        TrilT2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        TrilT2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TrilT2ActionPerformed(evt);
            }
        });

        T1E.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        T1E.setText(" Termostato 1");
        T1E.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                T1EActionPerformed(evt);
            }
        });

        T1E1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        T1E1.setText(" Termostato 2");
        T1E1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                T1E1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(102, 102, 102));
        jButton2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton2.setText("EV1");
        jButton2.setFocusable(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(102, 102, 102));
        jButton3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton3.setText("EV2");

        jButton4.setBackground(new java.awt.Color(102, 102, 102));
        jButton4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton4.setText("EV3");

        jButton5.setBackground(new java.awt.Color(102, 102, 102));
        jButton5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton5.setText("EV4");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jLabel2.setText("Delay");

        Delay.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        Delay.setText("2000");
        Delay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DelayActionPerformed(evt);
            }
        });

        jButton6.setText("SALVA");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        TsetT4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        TsetT4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TsetT4ActionPerformed(evt);
            }
        });

        TrilT3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        TrilT3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TrilT3ActionPerformed(evt);
            }
        });

        TsetT3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        TsetT3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TsetT3ActionPerformed(evt);
            }
        });

        TrilT4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

        T1E2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        T1E2.setText(" Termostato 3");
        T1E2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                T1E2ActionPerformed(evt);
            }
        });

        T1E3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        T1E3.setText(" Termostato 4");
        T1E3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                T1E3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(134, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(T1E)
                                            .addComponent(T1E1))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel4)
                                                .addGap(18, 18, 18)
                                                .addComponent(PORTA, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(4, 4, 4))
                                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(28, 28, 28)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(Delay, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jButton6)))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton4)
                                .addGap(18, 18, 18)
                                .addComponent(jButton5)
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(165, 165, 165)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(T1E2)
                                .addComponent(T1E3)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(136, 136, 136)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(TsetT4, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(41, 41, 41)
                                            .addComponent(TrilT4, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(TsetT3, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(41, 41, 41)
                                            .addComponent(TrilT3, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(TsetT2, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(41, 41, 41)
                                    .addComponent(TrilT2, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(TsetT1, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(41, 41, 41)
                                    .addComponent(TrilT1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addGap(137, 137, 137))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnClearTx)
                        .addGap(269, 269, 269))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(235, 235, 235))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton1)
                                .addGap(12, 12, 12)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(PORTA, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnClearTx)
                        .addGap(39, 39, 39)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(9, 9, 9)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(T1E)
                            .addComponent(TsetT1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TrilT1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TrilT2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(T1E1)
                            .addComponent(TsetT2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Delay, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(24, 24, 24)
                        .addComponent(jButton6)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(T1E2)
                    .addComponent(TsetT3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TrilT3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TrilT4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(T1E3)
                    .addComponent(TsetT4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 58, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnClearTxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearTxActionPerformed
        // TODO add your handling code here:
        
       
        
        Text1.setText("");
    }//GEN-LAST:event_btnClearTxActionPerformed

    private void Text1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Text1KeyPressed
        // TODO add your handling code here:
       
          
        
    }//GEN-LAST:event_Text1KeyPressed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
     
      ClientSTART=1;
                        
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void DelayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DelayActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DelayActionPerformed

    private void TrilT1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TrilT1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TrilT1ActionPerformed

    private void TsetT1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TsetT1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TsetT1ActionPerformed

    private void TsetT2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TsetT2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TsetT2ActionPerformed

    private void T1E1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_T1E1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_T1E1ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        
            x=1;
        
        
        
    }//GEN-LAST:event_jButton6ActionPerformed

    private void TsetT4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TsetT4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TsetT4ActionPerformed

    private void TrilT3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TrilT3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TrilT3ActionPerformed

    private void TsetT3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TsetT3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TsetT3ActionPerformed

    private void T1E3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_T1E3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_T1E3ActionPerformed

    private void T1E2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_T1E2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_T1E2ActionPerformed

    private void TrilT2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TrilT2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TrilT2ActionPerformed

    private void T1EActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_T1EActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_T1EActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Delay;
    private javax.swing.JTextField PORTA;
    private javax.swing.JCheckBox T1E;
    private javax.swing.JCheckBox T1E1;
    private javax.swing.JCheckBox T1E2;
    private javax.swing.JCheckBox T1E3;
    private javax.swing.JTextArea Text1;
    private javax.swing.JTextField TrilT1;
    private javax.swing.JTextField TrilT2;
    private javax.swing.JTextField TrilT3;
    private javax.swing.JTextField TrilT4;
    private javax.swing.JTextField TsetT1;
    private javax.swing.JTextField TsetT2;
    private javax.swing.JTextField TsetT3;
    private javax.swing.JTextField TsetT4;
    private javax.swing.JButton btnClearTx;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
