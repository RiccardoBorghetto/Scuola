/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

/**
 *
 * @author lenovo
 */
public class Termostato {
 String ip;
 int  porta;
 int temperaturaSET;
 int temperaturaRIL;
 int num_msg;
 int num_err;
 boolean enable;
   
Termostato(String ip, int porta)
    {
    this.ip=ip;
    this.porta=porta;
    temperaturaSET =0;
    temperaturaRIL =0;
    num_msg=0;
    num_err=0;
    }
    
}
