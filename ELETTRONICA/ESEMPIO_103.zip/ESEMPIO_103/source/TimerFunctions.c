#define _SUPPRESS_PLIB_WARNING

#include  <sys/attribs.h>

#include "TimerFunctions.h"
#include "extern_var.h"



unsigned char dato;
unsigned long int  msecCounter;
static int SW_Timer[NUM_TIMER];


static int SW_Timer_Reload[NUM_TIMER]={9,99,999,9999};
char SW_Timer_flag[NUM_TIMER];

   

unsigned int msTick;

void delay_ms(unsigned int ms)
	{
	msTick=ms;
    while(1)
		{
        if(msTick==0)
            break;
		
		}
	}


char Timer_Tick(unsigned char t)
    {
    return(SW_Timer_flag[t]);
    Nop();
    }
    
void Clear_Timer_Tick(unsigned char t)
    {
    SW_Timer_flag[t]=0;
    }



void Timer1Init(void)
    {
    char i;
    T1CON=0;
	T1CONbits.TCKPS=0;		// Input clock= PBCLK 
	PR1 = 2400;	        	// Timer period a 100 uS 


    IFS0bits.T1IF = 0;
	IEC0SET = (1<<17);		// timer 1 interrupt.       
	IPC4bits.T1IP = 3;		// Timer 1 priority is 3
    for(i=0;i<NUM_TIMER;i++)
        {
        SW_Timer[i]=SW_Timer_Reload[i];
        SW_Timer_flag[i]=0;
        }
    T1CONSET = 0x8000;		//Start the timer.		

    }
	
	
void Timer2Init(void)
    {
    char i;
    T2CON=0;
	T2CONbits.TCKPS=0;		// Input clock= PBCLK 
	PR2 = 1500;	        	// Timer period             

    IFS0bits.T2IF = 0;
	IEC0SET = (1<<18);		// timer 2 interrupt.
	IPC4bits.T2IP = 3;		// Timer 2 priority is 3
    IPC4bits.T2IS = 3;
    T2CONSET = 0x8000;		// Start the timer

    }

	
	
	
	
	
	

//------------------- interrupt TIMER 1 -------------------------
void __ISR(_TIMER_1_VECTOR, IPL4SOFT) Timer1InterruptHandler(void) 
    {
    unsigned char i;
    IFS0bits.T1IF = 0;	// clear interrupt flag
	LATBbits.LATB1^=1;
	   
  	Nop();
    if(msTick)
        msTick--;
    msecCounter ++;		// Increment millisecond counter.	
    
    for(i=0;i<NUM_TIMER;i++)
        if(!SW_Timer[i]--)
            {
            SW_Timer[i]=SW_Timer_Reload[i];
            SW_Timer_flag[i]=1;
            }
				
    }


//------------------- interrupt TIMER 2 -------------------------
void __ISR(_TIMER_2_VECTOR, IPL4SOFT) Timer2InterruptHandler(void) 
    {
    unsigned char i;
    IFS0bits.T2IF = 0;	// clear interrupt flag
	
    }