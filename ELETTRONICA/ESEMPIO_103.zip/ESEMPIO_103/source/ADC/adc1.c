
/**
  ADC1 Generated Driver File

  @Company
    Microchip Technology Inc.

  @File Name
    adc1.c

  @Summary
    This is the generated header file for the ADC1 driver using MPLAB(c) Code Configurator

  @Description
    This header file provides APIs for driver for ADC1.
    Generation Information :
        Product Revision  :  MPLAB(c) Code Configurator - pic24-dspic-pic32mm : v1.25
        Device            :  PIC32MM0064GPL028
        Driver Version    :  0.5
    The generated drivers are tested against the following:
        Compiler          :  XC32 1.42
        MPLAB 	          :  MPLAB X 3.45
*/



/**
  Section: Included Files
*/

#include <xc.h>
#include "adc1.h"


typedef struct
{
	uint8_t intSample;
} ADC_OBJECT;



struct {
char state;
short int adc_0;
short int adc_1;
short int Tempo;

} adc;
static ADC_OBJECT adc1_obj;

/**
  Section: Driver Interface
*/


void ADC1_Initialize (void)
{
 
    // --------------------    AD1CON1  -----------------------
   AD1CON1 =   0; 
   
   AD1CON1bits.ASAM   = 0;   // Sampling START quando SAMP bit è set
   AD1CON1bits.MODE12 = 1;   // mosalità 12 bit
   AD1CON1bits.SSRC   = 0;   // SAMP = 0 ==> STOP SAMPLING & START CONVERTION 
   AD1CON1bits.FORM   = 0;   // Integer 16 bit allineato a   Dx
   AD1CON1bits.SIDL   = 0;   // continua in IDLE mode
   AD1CON1bits.ON     = 1;   	// ADC Enable

   
   // --------------------    AD1CON2  -----------------------
   AD1CON2   = 0;
   
   AD1CON2bits.BUFM     = 0;  // Buffer Mode come 22 word
   AD1CON2bits.SMPI     = 0;  // Modalità Interrupt ??????
   AD1CON2bits.BUFS     = 0;  // Segnalazione Buffer ??????
   AD1CON2bits.CSCNA    = 0;  // No scan mode
   AD1CON2bits.BUFREGEN = 0;  // ADC Buffer come FIFO
   AD1CON2bits.OFFCAL   = 0;  // NO Calibration Mode
   AD1CON2bits.VCFG     = 0;  // ADC Vref+ = AVdd   ADC Vref- = AVss

   // --------------------    AD1CON3  -----------------------
   AD1CON3 = 0;
   AD1CON3bits.ADRC   = 0;    	// PBCLK
   AD1CON3bits.EXTSAM = 0;		// EXTSAM disable 
   AD1CON3bits.SAMC   = 31;     // Auto Sampling Time = 31 Tad   
   AD1CON3bits.ADCS   = 4;      // Tad = (4+1) Tsrc 
   
   
   // --------------------    AD1CON5  -----------------------
   AD1CON5 = 0;
   
  

   // CH0SA AN0; CH0NA AVSS;
   AD1CHS = 0x0;

    // CSS9 disabled; CSS8 disabled; CSS7 disabled; CSS6 disabled; CSS5 disabled; CSS4 disabled; CSS3 disabled; CSS2 disabled; CSS1 disabled; CSS0 disabled; CSS11 disabled; CSS10 disabled; CSS30 disabled; CSS29 disabled; CSS28 disabled; 
   AD1CSS = 0x0;

    // CHH2 disabled; CHH1 disabled; CHH0 disabled; CHH11 disabled; CHH10 disabled; CHH9 disabled; CHH8 disabled; CHH7 disabled; CHH6 disabled; CHH5 disabled; CHH4 disabled; CHH3 disabled; 

   AD1CHIT = 0x0;

}











void ADC1_Start(void)
{
   AD1CON1SET = (1 << _AD1CON1_SAMP_POSITION);
}
void ADC1_Stop(void)
{
   AD1CON1CLR = (1 << _AD1CON1_SAMP_POSITION);
}



uint16_t ADC1_ConversionResultBufferGet(uint16_t *buffer)
{
    int count;
    /*
    uint16_t *ADC16Ptr;

    ADC16Ptr = (uint16_t *)&(ADC1BUF0);

    for(count=0;count<=adc1_obj.intSample;count++)
    {
        buffer[count] = (uint16_t)*ADC16Ptr;
        ADC16Ptr++;
    }
  * */
    return count;
}

uint16_t ADC1_ConversionResultGet(void)
	{
    return ADC1BUF0;
	}
bool ADC1_IsConversionComplete( void )
	{
    return AD1CON1bits.DONE; //Wait for conversion to complete   
	}
void ADC1_ChannelSelect( ADC1_CHANNEL channel )
	{
    AD1CHS = channel;
	}


void ADC1_Tasks ( void )
	{
    // clear the ADC interrupt flag
	//    IFS0CLR= 1 << _IFS0_AD1IF_POSITION;
	}

void ADC1_gest(void)
	{
	switch(adc.state)
		{
		case 0:
			ADC1_ChannelSelect(ADC1_ANALOG_14);
			AD1CON1bits.SAMP=1;  // start SAMPLE
			adc.state=2;
            adc.Tempo =0;
			return;
            
        case 1:
            if(adc.Tempo--)
                return;
            adc.state=2;
            return;
		
		case 2:
			AD1CON1bits.SAMP=0;  // STOP SAMPLE & START CONVERTION
			adc.state=4;
            adc.Tempo =0;
			return;
		case 3:
            if(adc.Tempo--)
                return;
            adc.state=4;
			return;
	 		
		case 4:
            Nop();
            if(AD1CON1bits.DONE==0)
                return;
            adc.adc_0 = ADC1BUF0;
            
            LATCbits.LATC13^=1;
            adc.state=10;
			return;
			
			
		case 10:
			ADC1_ChannelSelect(ADC1_ANALOG_13);
			AD1CON1bits.SAMP=1;  // start SAMPLE
			adc.state=12;
            adc.Tempo =0;
			return;
            
        case 11:
            if(adc.Tempo--)
                return;
            adc.state=12;
            return;
		
		case 12:
			AD1CON1bits.SAMP=0;  // STOP SAMPLE & START CONVERTION
			adc.state=14;
            adc.Tempo =0;
			return;
		case 13:
            if(adc.Tempo--)
                return;
            adc.state=14;
			return;
	 		
		case 14:
            Nop();
            if(AD1CON1bits.DONE==0)
                return;
            adc.adc_1 = ADC1BUF0;
            
            LATCbits.LATC13^=1;
            adc.state=0;
			return;	
			
			
		}
	
	}




/**
  End of File
*/
