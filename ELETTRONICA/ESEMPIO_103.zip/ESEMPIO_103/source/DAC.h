#ifndef __DAC_H
#define __DAC_H

void writeDAC(uint16_t val, uint8_t ch);
void rampaDAC(void);
void ondaquadraDAC(void);
void senoDAC(void);
void ondatriangolareDAC(void);

#endif
