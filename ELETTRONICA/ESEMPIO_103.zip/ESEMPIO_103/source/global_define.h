#ifndef __GLOBAL_DEFINE_H
#define __GLOBAL_DEFINE_H

#include <xc.h>

#define SYS_FREQ 			(40000000L)

#define XTFREQ          8000000         		//On-board Crystal frequency
#define PLLMODE         2               		//On-chip PLL setting
#define FCY             XTFREQ*PLLMODE        //Instruction Cycle Frequency

#define BAUDRATE         50000
#define BRGVAL          ((FCY/BAUDRATE)/16)-1


#define  LED_ROSSO_ON  LATDbits.LATD1=1;
#define  LED_ROSSO_OFF  LATDbits.LATD1=0;
#define  LED_ROSSO_TOG  LATDbits.LATD1^=1;




#endif

