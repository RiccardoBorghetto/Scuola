#define _SUPPRESS_PLIB_WARNING
#include  <sys/attribs.h>

#include <xc.h>

#include "TimerFunctions.h"
#include "extern_var.h"

#include "DAC.h"



uint8_t modo =0;

unsigned char pSENO=0;
unsigned short int Tab_SENO[16]={
	
	2047,
	2830,
	3495,
	3939,
	4095,
	3940,
	3497,
	2833,
	2050,
	1267,
	602,
	157,
	0,
	153,
	595,
	1258
	
};


unsigned short int Tab_SENO32[32]={

2047,
2446,
2830,
3184,
3495,
3749,
3939,
4055,
4095,
4056,
3940,
3751,
3497,
3187,
2833,
2450,
2050,
1651,
1267,
912  ,
602  ,
347  ,
157  ,
39   ,
0   ,
37   ,
153  ,
341  ,
595  ,
904  ,
1258,
1641};





uint16_t valDAC = 0;
uint16_t valDAC_A = 0;

struct
    {
    unsigned char state;
    unsigned char writeA;
	unsigned char writeB;
	uint16_t  val_A;
	uint16_t  val_B;
	
    }DAC; 


void writeDAC(uint16_t val, uint8_t ch)
	{
	uint16_t Temp;
	LATCbits.LATC11=0;  // CS LOW
	Temp = val;
	Temp=Temp>>8;  // estrae MSB
	Temp&=0x000F;
	Temp|=0x30;
    if(ch ==1)
        Temp|=0x80;   
	
	SPI3BUF=Temp;   
	Nop();	Nop();	Nop();	Nop(); Nop();	Nop();	
	SPI3BUF=val;
	Nop();	Nop();	Nop();	Nop();Nop();	Nop();	
	Nop();	Nop();Nop();	Nop();	Nop();	Nop();
	
	while(SPI3STATbits.SRMT==0);
	LATCbits.LATC11=1; // CS HIGH
		
	}
	

void ondatriangolareDAC(void){
	writeDAC(valDAC,1);
	
    if(modo == 0){
        valDAC+=100;
        if(valDAC>=4096)
        {modo = 1; valDAC=4095;} 
    }
    else{
         valDAC-=100;
        if(valDAC<=0)
            { modo = 0; valDAC = 0;}    
    }
    
}



	
	
void rampaDAC(void){
	writeDAC(valDAC,0);
	valDAC+=100;
	if(valDAC>=4096)
		valDAC = 0;
	
	
}

void ondaquadraDAC(void){
	writeDAC(valDAC,0);
	valDAC ^= 0xFFF;
	
}
	

void senoDAC(void){
	
	valDAC_A = Tab_SENO32[pSENO++];
	writeDAC(valDAC_A,0);
	if(pSENO > 31)
		pSENO = 0;
	
	
}

