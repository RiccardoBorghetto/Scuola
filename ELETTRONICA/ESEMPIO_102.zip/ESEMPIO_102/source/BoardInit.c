#define _SUPPRESS_PLIB_WARNING

#include  <sys/attribs.h>

#include "TimerFunctions.h"
#include "extern_var.h"


 /*********************************************************************
 * Function:        void BoardInit( void )
 *
 ********************************************************************/
void BoardInit(void)
	{
   
	//------------------------------------------------------  PORTA A ---------------------
    TRISAbits.TRISA0 = 1;  		//	  	PGC2   Prog/Debug	
	TRISAbits.TRISA1 = 1;  		//	  	PGD2   prog/Debug		
    TRISAbits.TRISA2 = 1;  		//     
	TRISAbits.TRISA3 = 1;  		//     
	TRISAbits.TRISA4 = 1;  		//		 
	TRISAbits.TRISA7 = 1;  		//		 
	TRISAbits.TRISA8 = 1;  		//		
	TRISAbits.TRISA9 = 1;  		//		
	TRISAbits.TRISA10 = 1;  	//     

    TRISAbits.TRISA12 = 1;  	//
	TRISAbits.TRISA14 = 1;  	//   

    ODCA=0b0000000000000000;  	// 		impostazione Open Drain
    ANSELA=0x0000;            	// 		NO  Analog pin
	
	//------------------------------------------------------  PORTA B ---------------------
    TRISBbits.TRISB0 = 0;  		//     TEST PIN 
	TRISBbits.TRISB1 = 0;  		//     
	TRISBbits.TRISB2 = 1;  		//		
	TRISBbits.TRISB3 = 1;  		//		 
	TRISBbits.TRISB4 = 1;  		//	  
	TRISBbits.TRISB5 = 1;  		//		
		
	TRISBbits.TRISB7 = 1;  		//		
	TRISBbits.TRISB8 = 1;  		//		 
	TRISBbits.TRISB9 = 1;  		//		PULSANTE_S1
	TRISBbits.TRISB10 = 1;  	//	    USB D+
	TRISBbits.TRISB11 = 1;  	//	    USB D-
	
	TRISBbits.TRISB13 = 0;  	// 	
	TRISBbits.TRISB14 = 0;  	// 	
	TRISBbits.TRISB15 = 0;  	// 	

    ODCB=0b0000000000000000;  	// 		impostazione Open Drain
    ANSELB=0x0000;            	// 		NO  Analog pin
	
	// -------------------------------------------------    PORTA C ----------------------
	TRISCbits.TRISC0 = 1;  		//		
	TRISCbits.TRISC1 = 1;  		//		
	TRISCbits.TRISC2 = 1;  		//		
    TRISCbits.TRISC3 = 0;  		//    	LED_RGB_GREEN
	TRISCbits.TRISC4 = 1;  		//     	PULSANTE_S3 
	TRISCbits.TRISC5 = 0;  		//		
	TRISCbits.TRISC6 = 1;  		//		
	TRISCbits.TRISC7 = 1;  		//		
	TRISCbits.TRISC8 = 1;  		//		 ANALOG POT. 
	TRISCbits.TRISC9 = 1;  		//		              
	TRISCbits.TRISC10 = 1;  	//		PULSANTE_S2
	TRISCbits.TRISC11 = 0;  	//		CS_SPI
	TRISCbits.TRISC13 = 0;  	//		LED_2
    TRISCbits.TRISC14 = 1;  	//		
    TRISCbits.TRISC15 = 0;  	//		LED_RGB_BLU

    ODCC=0b0000000000000000;  	// 		impostazione Open Drain
    ANSELC=0x0000;            	// 		NO  Analog pin
	
	
	//--------------------------------------------------------
    TRISDbits.TRISD0 = 1;  		//		
	TRISDbits.TRISD1 = 0;  		//  	RGB_LED_RED
    TRISDbits.TRISD3 = 0;  		//  	LED_1
    TRISDbits.TRISD4 = 1;  		//  
    

    ODCD=0b0000000000000000;  	// 		impostazione Open Drain
    ANSELD=0x0000;            	// 		NO  Analog pin    
    }