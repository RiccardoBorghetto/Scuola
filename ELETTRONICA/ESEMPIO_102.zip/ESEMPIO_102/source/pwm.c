#define _SUPPRESS_PLIB_WARNING
#include  <sys/attribs.h>

#include <xc.h>
#include "TimerFunctions.h"
#include "extern_var.h"



extern unsigned short int Tab_SENO[16];
unsigned char pSENO1 =0;
unsigned char pSENO2 =4;

void init_PWM(void )
	{
	//------------- configura modulo CCP1 come PWM -----------------
    CCP1CON1 = 0;
    CCP1CON2 = 0;
    CCP1CON3 = 0;
    CCP1CON1bits.MOD = 0b0100;      //dual edge compare mode
    CCP1CON2bits.OCDEN = 1;         //enable OCM1D/RC5
    CCP1TMR = 0;
    CCP1RA = 0;
    CCP1RB = 512;
    CCP1PR = 0x3FF;
    CCP1CON1bits.ON = 1;
	
	
	
	//------------- configura modulo CCP2 come PWM -----------------
    CCP2CON1 = 0;
    CCP2CON2 = 0;
    CCP2CON3 = 0;
    CCP2CON1bits.MOD = 0b0100;      //dual edge compare mode
    
	// seleziona PIN uscita PWM 
	// CCP2CON2bits.OCBEN = 1;      //enable OCM2B/RC3 
	CCP2CON2bits.OCCEN = 1;         //enable OCM2C/RB0
			
    CCP2TMR = 0;
    CCP2RA = 0;
    CCP2RB = 512;
    CCP2PR = 0x3FF; // 1023
    CCP2CON1bits.ON = 1;
	
	}




void senoPWM(uint8_t ch){
	
	uint16_t val;
	
	
	switch(ch)
		{
		case 1:
			val = Tab_SENO[pSENO1++];
			val = val >> 2;
	
			CCP1RB = ((uint32_t)val);
	
			if(pSENO1 > 15)
				pSENO1 = 0;
			break;
		
		case 2:
			val = Tab_SENO[pSENO2++];
			val = val >> 2;
	
			CCP2RB = ((uint32_t)val);
	
			if(pSENO2 > 15)
				pSENO2 = 0;
			break;
		
		default: 
			break;
		
		
		}
	
	
}

uint16_t valPWM1 =0;
uint16_t valPWM2 =0;

void ondaquadraPWM(uint8_t ch){
	
	uint16_t val;
	
	
	switch(ch)
		{
		case 1:
			
            
	        valPWM1 ^= 0x7FF;
			CCP1RB = ((uint32_t)valPWM1);
	
			
			break;
		
		case 2:
			 valPWM2 ^= 0x3FF;
	
			CCP2RB = ((uint32_t)valPWM2);
	
			
			break;
		
		default: 
			break;
		
		
		}
	
    
	
	
}


void dentedisegaPWM(uint8_t ch){
	
	
	
	
	switch(ch)
		{
		case 1:
			
            
	        valPWM1 +=2;
            if(valPWM1>1023)
                valPWM1=0;
			CCP1RB = ((uint32_t)valPWM1);
	
			
			break;
		
		case 2:
            
            valPWM2 +=2;
            if(valPWM2>1023)
                valPWM2=0;
			CCP2RB = ((uint32_t)valPWM2);
	
			
			break;
		
		default: 
			break;
		
		
		}
	
	
}