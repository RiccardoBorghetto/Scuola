

#ifndef _TIMER_FUNCTIONS_H_
#define _TIMER_FUNCTIONS_H_

#include "GenericTypeDefs.h"
#include <p32xxxx.h>


#define NUM_TIMER  4

void Timer1Init(void);
void Timer3Init(void);

char Timer_Tick(unsigned char t);
void Clear_Timer_Tick(unsigned char t);
void Timer2Init(void);
void delay_ms(unsigned int ms);
void Beep(unsigned short int n);
void Beep_1(unsigned short int n);

void gest_timer1(void);



#endif

