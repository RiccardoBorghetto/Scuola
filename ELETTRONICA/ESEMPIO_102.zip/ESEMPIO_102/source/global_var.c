


unsigned int TickTimer;


unsigned short int Ing;
unsigned short int Ing_old;
unsigned short int Ing_FRL;
unsigned short int Ing_FRH;

 

unsigned short int ADC_CHA0;
unsigned short int ADC_CHA1;

