/*********************************************************************
 *    FABIO: prove varie
 *********************************************************************
 * Processor:      PIC32MX250F128D  
 *
 * Complier:        XC32  1.44
 *                  MPLABX 
 * Company:         Microchip Technology Inc.
 *
 * 
 *********************************************************************
 *  Versione    : 1.00     
 *  Data        : gg/mm/aaaa 
 * --------------------------------------------------------------------
 * Versione Prec: _____  
 * --------------------------------------------------------------------
 * Note: versione HARDWARE ______
 *
 * 
 *----------------------------------------------------------------------
 * Modifiche:   1-  
 *  				
 *              2-  
 * 
 * 
 * 
 * 
 * 

 *
 ********************************************************************/

#define _SUPPRESS_PLIB_WARNING
#include <p32xxxx.h>

#include "config.h"

#include <xc.h>
#include  <sys/attribs.h> 

#include <string.h>

#include "TimerFunctions.h"
#include "BoardInit.h"
#include "DAC.h"
#include "spi.h"
#include "tast.h"

#include "extern_var.h"
#include "global_define.h"



/******* Variables ***********************************/

 uint8_t pulsante; 
 
 void SYSTEM_Initialize(void);
 




// the main program
void main(void)
	{
    	
	// inizializza PLL per ottenere max. frequenza 
	//per CPU e PERIFERICHE ( 24 MHz)
	SYSTEM_Initialize();					
		
    INTCONbits.MVEC = 1;             	//  Enable the multi vector interrupts
   __builtin_enable_interrupts();   	// enable interrupts
  
    BoardInit();
    Timer1Init();
    IFS0bits.T1IF = 0;
	//init_SPI3();
	
	init_PWM();
	
	
    while(1)
        {
        //----------------- TICK  a 1 ms -----------------
        if(Timer_Tick(0) )
            {
            Clear_Timer_Tick(0);
           // LATBbits.LATB0^=1;
			//senoPWM(1);
			//senoPWM(2);
            //ondaquadraPWM(1);
            //ondaquadraPWM(2);
            dentedisegaPWM(2);
            
			}
        //----------------- TICK  a 10 ms -----------------
        if(Timer_Tick(1) )
            {
            Clear_Timer_Tick(1);
			
			//senoPWM(1);
			//senoPWM(2);
			
            
            
			if(Tast())
				{
				LATCbits.LATC13^=1;
				pulsante = getKey();
				if(pulsante == 1)
				  LATDbits.LATD1 ^=1 ;	
				if(pulsante == 2)
				  LATCbits.LATC3 ^=1 ;	
				if(pulsante == 4)
				  LATCbits.LATC15 ^=1 ;	
				}
			}
        
		 //----------------- TICK  a 100 ms -----------------
        if(Timer_Tick(2) )
            {
            Clear_Timer_Tick(2);
		
			}
		
		
        //----------------- TICK  a 0.5 S -----------------
        if(Timer_Tick(3) )
            {
            Clear_Timer_Tick(3);
			LATDbits.LATD3 ^= 1;
		 
			}
        
        }
	
	} // main
    

	
	
	
	
	
	
void SYSTEM_Initialize(void)
	{
    volatile uint32_t i;
    
   
       

    //Unlock sequence for SPLLCON and OSCCON registers.
    SYSKEY = 0;// force lock
    SYSKEY = 0xAA996655;  // unlock sequence
    SYSKEY = 0x556699AA;  // lock sequence

    //Temporarily switch to 8MHz FRC (without PLL), so we can safely change the PLL settings,
    //in case we had previously been already running from the PLL.
    OSCCON = OSCCON & 0xF8FFF87E;    //FRC configured for 8MHz output, and set NOSC to run from FRC with divider but without PLL.
    if(OSCCONbits.COSC != OSCCONbits.NOSC)
		{
        //Initiate clock switching operation.
        OSCCONbits.OSWEN = 1;
        while(OSCCONbits.OSWEN == 1);    //Wait for switching complete.
		}

    //Configure the PLL to run from the FRC, and output 24MHz for the CPU + Peripheral Bus (and 48MHz for the USB module)
    SPLLCON = 0x02050080;     //PLLODIV = /4, PLLMULT = 12x, PLL source = FRC, so: 8MHz FRC * 12x / 4 = 24MHz CPU and peripheral bus frequency.

    //Now switch to the PLL source.
    OSCCON = OSCCON | 0x00000101;    //NOSC = SPLL, initiate clock switch (OSWEN = 1)


    //Wait for PLL startup/lock and clock switching operation to complete.
    for(i = 0; i < 100000; i++)
		{
        if((CLKSTATbits.SPLLRDY == 1) && (OSCCONbits.OSWEN == 0))
            break;
		}    

    //Enable USB active clock tuning for the FRC
    OSCTUN = 0x00009000;    //active clock tuning enabled, source = USB

    SYSKEY = 0;             //Re-lock oscillator registers  

    INTCONbits.MVEC = 1;
    asm volatile("ei $0");
    
}
	
	
	
	
	
	


	 
	 
	 
        
     
 