#define _SUPPRESS_PLIB_WARNING
#include  <sys/attribs.h>
#include <xc.h>


void init_SPI3(void)
    {
    SPI3CON = 0; 			// Stops and resets the SPI3.
    SPI3BRG=2; 				// use FPB/4 clock frequency
    SPI3STATCLR=0x40; 		// clear the Overflow
    SPI3CON=0x00008320; 	// SPI ON, 8 bits transfer, SMP=1, Master mode
	return;
	
  
    }
 
