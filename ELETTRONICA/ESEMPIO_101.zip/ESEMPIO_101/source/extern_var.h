
extern unsigned  char   Sollevatore_Chiuso;
extern unsigned  char   Sollevatore_Aperto;
extern unsigned char Tempo_CONTATORE;

extern unsigned int ContaCicli;
extern unsigned int ContaCicliOld;

extern char  msg_buffer[32];
extern unsigned char PALMARE_PRESENTE;
extern                      
unsigned char dati_LCD[80];

extern unsigned int TickTimer;

extern unsigned char Pulsanti;
extern unsigned char Pulsanti_Radio;
extern unsigned char TimeOut_Radio;
extern unsigned int  Puls_Radio;
extern unsigned int  Puls_Radio_FRH;
extern unsigned int  Puls_Radio_FRL;
extern unsigned int  Puls_Radio_old;

extern unsigned char cksum;
extern unsigned char status;



extern unsigned short int Ing;
extern unsigned short int Ing_old;
extern unsigned short int Ing_FRL;
extern unsigned short int Ing_FRH;




extern 
struct {
        unsigned char fase;
        unsigned char conta;
        unsigned char conta1;
        unsigned int  Tempo;
		} CS;


extern unsigned char Key_PC;

extern unsigned char LED_ONOFF;
extern unsigned char stato_PRESSIONE;
extern unsigned int TEMPERATURA_NTC;
extern unsigned int SEGMENTI[16];
extern unsigned short int TempoRiavvio;
extern unsigned short int RitAllSensoreP;
extern unsigned short int RitAllOverVoltage;
extern unsigned short int RitAllUnderVoltage;

extern unsigned char AGGIORNA_DATI_R;
extern unsigned short int Conta_Rx_MODEM;
extern unsigned char buffer_invio[64];

extern 
struct struct_LED
       {
       unsigned char fase;
       unsigned char MODO;    // 
       unsigned char conta;
       unsigned char conta_copia;
       short int  Tempo;
       short int  Tempo_ON;
       short int  Tempo_OFF;
       short int  Tempo_PAUSA;
       
       }LB[5];
       

/*
extern struct
    {
    
    unsigned char rx_over:1;
    unsigned char NONE:7;
    unsigned char Trama_OK;
    unsigned char rx_conta;
    unsigned char rx_num_car;
    unsigned char rx_buffer[32];
    unsigned char rx_stato;
    unsigned char tx_buffer[32];
    unsigned char * tx_msg;
    unsigned char tx_CNT_read;
    unsigned char tx_CNT_write;

    unsigned char msg_fase;
    unsigned char msg_TENTATIVI;
    unsigned char msg_NUM_TENTATIVI;
    unsigned char msg_TIMEOUT;
    unsigned char msg_START;
    unsigned char msg_CMD;
    
    }com1;
  */
  
  extern   struct
        {
        unsigned char trama_ok:1;
        unsigned char NONE:7;
        unsigned char stato_SLAVE;
        unsigned char rx_conta;
        unsigned char rx_buffer[64];
        unsigned char rx_stato;
        unsigned char tx_buffer[64];
        unsigned char tx_CNT_read;
        unsigned char tx_CNT_write;
        unsigned int  Tempo;
        unsigned char TEMPO_RESET;

		unsigned char msg_fase;
        unsigned char msg_TENTATIVI;
        unsigned char msg_NUM_TENTATIVI;
        unsigned char msg_TIMEOUT;
        unsigned char msg_MAIL_BOX;
		} com1;
  
  
  
  
  
  
  


extern unsigned short int LAMP_LED;
extern unsigned short int LAMP_LED_X;
extern union   {
        struct
            {
            char ALL_UnderVoltage:1;
            char ALL_OverVoltage:1;
            char ALL_OverCurrent:1;
            char ALL_MarciaSecco:1;
            char ALL_SensoreP:1;
			char ALL_NoFase:1;
			char ALL_Modem:1;
			char ALL_BLOCCO_MS:1;
			char ALL_TEMPERATURA:1;
			char ALL_TRIP_I:1;
			char ALL_ING0:1;
			char ALL_ING1:1;
			char NONE:4;
            } flag;
       unsigned short int      word;
      } All;
	  
	  
	  
	extern   
	 struct {
        unsigned char fase;
        unsigned char conta;
        unsigned char conta1;
        unsigned int  Tempo;
		unsigned int  NUM_TENTATIVI;
		unsigned int  SCALA_T;
		
       } MS;

extern unsigned char TEMPI_MS[16];
extern unsigned int I_Limite;
extern unsigned int Cosphi_Limite;
extern unsigned int Cosphi_Misurato;












extern unsigned short int ADC_Analog[16];
extern unsigned short int PressioneMisurata;
extern unsigned short int ScalaSensorePressione[13];
extern unsigned char Ing_0;
extern unsigned char Ing_1;


extern unsigned char LivBarra;
 
 extern unsigned char Stato_Pompa;
 extern unsigned char ManAuto;
 
 extern unsigned char  PAYLOAD_RX[32];
extern unsigned char  PAYLOAD_TX[32];
 
 
 extern struct
    {
    
    unsigned char rx_over:1;
    unsigned char NONE:7;
    unsigned char Trama_OK;
    unsigned char rx_conta;
    unsigned char rx_num_car;
    unsigned char rx_buffer[32];
    unsigned char rx_stato;
    unsigned char tx_buffer[32];
    unsigned char * tx_msg;
    unsigned char tx_CNT_read;
    unsigned char tx_CNT_write;

    unsigned char msg_fase;
    unsigned char msg_TENTATIVI;
    unsigned char msg_NUM_TENTATIVI;
    unsigned char msg_TIMEOUT;
    unsigned char msg_START;
    unsigned char msg_CMD;
    
    }com3;
 
 extern unsigned char  PAGINA;
 extern unsigned short int Tempo_Tx;
 extern unsigned short int Tempo_Rx;


 extern unsigned char  PAYLOAD_RX[32];
 extern unsigned char  PAYLOAD_TX[32];

 extern unsigned char  com_50H[32];
extern unsigned char  com_24H[32];
extern unsigned char  com_0CH[32];
extern unsigned char  com_08H[32];

extern struct
        {
        unsigned char state;
		unsigned char FARE_RESET;
        unsigned int  Tempo;
        unsigned char CMD;
        unsigned short int CNT_RX;
        unsigned short int CNT_TX;
		unsigned short int CNT_RX1;
		} GM;
		
extern struct
        {
        unsigned char state;
		unsigned char CNT_ERRORI;
	    unsigned short int  Tempo;
		unsigned short int Tempo1;
        unsigned short int Errori;
        unsigned short int Temp;
		unsigned short int ERRORI_TOTALI;
		unsigned short int Tempo2;
		
		
		} GAM;				
		
extern unsigned char Status_MODEM;
extern unsigned short int Frequenza_Mot;
extern unsigned short int Frequenza_Imp;



extern unsigned int Dati_RW[40];
extern unsigned int Dati_R[40];

extern unsigned int Dati_RWpc[40];
extern unsigned int Dati_Rpc[40];




//extern unsigned char Soglia_Ix=0;
extern unsigned  short int LIVELLI_SFORZO[4];

extern unsigned short int TimeOutChiusura;
extern unsigned short int TimeOutApertura;
extern unsigned short int YYY;
extern unsigned short APRE_TEMPO;

extern unsigned char ZERO_OK;

extern struct
    {
    unsigned char state;
    unsigned int Tempo;
    
    }CT;
extern struct
    {
    unsigned char state;
    unsigned int Tempo;
    
    }Rr;


extern int   Wfeed_M1;
extern int   Wfeed_M3;







extern struct
    {
    unsigned char fase;
    unsigned int Tempo;
    
    }GLA12;

    
extern struct
    {
    unsigned char fase;
    unsigned int Tempo;
    
    }GLMS;
	
extern struct
    {
    unsigned char fase;
    unsigned int Tempo;
    
    }GL_ON_OFF;



	
 extern unsigned char ALL_ENCODER_M12;
  extern unsigned char ALL_ENCODER_M34;
 extern unsigned short int buff1_debug[128];
extern unsigned short int  pB1;

extern unsigned short int buff2_debug[256];
extern unsigned char pB2;



 extern unsigned short int Encoder_M1;
 extern unsigned short int Encoder_M2;
 extern unsigned short int Encoder_M3;
 extern unsigned short int Encoder_M4;
 extern short int Diff_Encoder_M12;
 extern short int Diff_Encoder_M34;
 
 extern unsigned short int dddOLD;
 extern unsigned short int eeeOLD;
 extern unsigned short int dddNOW;
 extern unsigned short int eeeNOW;
 
 
 extern unsigned short int dddCHANGE;
 extern  unsigned short int eeeCHANGE;

 extern  char KEY_STATUS;



  extern unsigned char  buff_BIT[128];
  extern unsigned char  pBIT;




extern unsigned char Rifare_AUTO_APP;



extern unsigned char Val_contrasto;
extern unsigned char modo_LCD;

      
extern unsigned char Key_Stato;
extern unsigned char New_Key;
extern unsigned  char Key;
extern unsigned char AntiR;
extern unsigned short int TimeOutKey;


 extern union
    {
    struct
        {
        unsigned char U00:1;
        unsigned char U01:1;
        unsigned char U02:1;
        unsigned char U03:1;
        unsigned char U04:1;
        unsigned char U05:1;
        unsigned char U06:1;
        unsigned char U07:1;
        unsigned char U08:1;
        unsigned char U09:1;
        unsigned char U10:1;
        unsigned char U11:1;
        unsigned char NONE:4;
        } bits;
    unsigned short int word;
    } Uscite;


                
        
extern 
struct
        {
        unsigned char fase;
		unsigned char NT;
        unsigned short int conta;
		unsigned int Tempo;
		unsigned char CONTA_ALL_FASE;
		unsigned char fase_old;
		       
        } C1;
        
        
 extern unsigned short int Isense_M1;
 extern unsigned short int I_picco_M1;
extern unsigned short int Isense_M2;
extern unsigned short int I_picco_M2;
extern unsigned short int Isense_M3;
extern unsigned short int I_picco_M3;
extern unsigned short int Isense_M4;
extern unsigned short int I_picco_M4;
        
        

        
        

       

 extern   struct {
       char state;
       char STOP;
       unsigned char APRE;
       unsigned char CHIUDE;

       } AP;  


extern  struct {
       char state;
       char STOP;
       unsigned char APRE;
	   unsigned char APRE1;
       unsigned char CHIUDE;
	   unsigned char CHIUDE1;

       } GAC;  
	   	   


extern struct
    {
    unsigned char b1:1;
    unsigned char b2:1;
    unsigned char b3:1;
    unsigned char b4:1;
    unsigned char b5:1;
    unsigned char b6:1;
    unsigned char b7:1;
    unsigned char b8:1;

    }DIPSW;
