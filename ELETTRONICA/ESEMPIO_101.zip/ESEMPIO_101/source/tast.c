#define _SUPPRESS_PLIB_WARNING
#include  <sys/attribs.h>
#include <xc.h>


	
unsigned char Key_Stato;
unsigned char New_Key;
unsigned  char Key;
unsigned char AntiR;



uint8_t getKey(void)
	{
	 return Key;
	}


 unsigned int Tast(void)
    {
    int   i;
    
    Key=0;
	if(PORTCbits.RC4==0)  // S3
        Key|=4;
    if(PORTCbits.RC10==0)  // S2
        Key|=2;
    if(PORTBbits.RB9==0)	// S1
        Key|=1;
         
    if(Key!=0)                        // se tasto premuto allora
        {                               // determina tasto
        AntiR++;
        if(AntiR>=3)
    	    {
      		if(Key_Stato!=0)           // se tasto precedente premuto
                return 0;              // restituisce 0
            Key_Stato=1;
     		return 1 ;
            }
        return 0 ;
        } 
    AntiR=0;
    Key_Stato=0;
    return 0 ;
    }
