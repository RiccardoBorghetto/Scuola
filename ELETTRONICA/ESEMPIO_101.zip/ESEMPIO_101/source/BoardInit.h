#ifndef __BOARDINIT_H
#define __BOARDINIT_H
void BoardInit(void);



#endif

