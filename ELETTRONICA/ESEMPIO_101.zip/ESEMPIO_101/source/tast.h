#ifndef __SPI_H
#define __SPI_H
unsigned int Tast(void);
uint8_t getKey(void);

#endif
