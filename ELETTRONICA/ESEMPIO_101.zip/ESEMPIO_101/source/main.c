/*********************************************************************
 *    FABIO: prove varie
 *********************************************************************
 * Processor:      PIC32MX250F128D  
 *
 * Complier:        XC32  1.44
 *                  MPLABX 
 * Company:         Microchip Technology Inc.
 *
 * 
 *********************************************************************
 *  Versione    : 1.00     
 *  Data        : gg/mm/aaaa 
 * --------------------------------------------------------------------
 * Versione Prec: _____  
 * --------------------------------------------------------------------
 * Note: versione HARDWARE ______
 *
 * 
 *----------------------------------------------------------------------
 * Modifiche:   1-  
 *  				
 *              2-  
 * 
 * 
 * 
 * 
 * 

 *
 ********************************************************************/

#define _SUPPRESS_PLIB_WARNING
#include <p32xxxx.h>

#include "config.h"

#include <xc.h>
#include  <sys/attribs.h> 

#include <string.h>

#include "TimerFunctions.h"
#include "BoardInit.h"
#include "DAC.h"
#include "spi.h"
#include "tast.h"

#include "extern_var.h"
#include "global_define.h"



/******* Variables ***********************************/

 uint8_t pulsante; 
 




// the main program
void main(void)
	{
        
    
    INTCONbits.MVEC = 1;            //  Enable the multi vector interrupts
   __builtin_enable_interrupts();   // enable interrupts
    BoardInit();                    //imposta le porte I/O
    Timer1Init();                   
    IFS0bits.T1IF = 0;              
	init_SPI3();                    
    
   		
	
    while(1)
        {
        //----------------- TICK  a 2 ms -----------------
        if(Timer_Tick(0) )
            {
            Clear_Timer_Tick(0);
            //LATBbits.LATB0^=1;
			
				//rampaDAC();
				//ondaquadraDAC();
			senoDAC();
            cosenoDAC();
             //ondatriangolareDAC();
			}
        //----------------- TICK  a 10 ms -----------------
        if(Timer_Tick(1) )
            {
            Clear_Timer_Tick(1);
			if(Tast())
				{
				LATCbits.LATC13^=1;
				pulsante = getKey();
				if(pulsante == 1)
				  LATDbits.LATD1 ^=1 ;	
				if(pulsante == 2)
				  LATCbits.LATC3 ^=1 ;	
				if(pulsante == 4)
				  LATCbits.LATC15 ^=1 ;	
				}
		
			}
        
		 //----------------- TICK  a 100 ms -----------------
        if(Timer_Tick(2) )
            {
            Clear_Timer_Tick(2);
		
			}
		
		
        //----------------- TICK  a 0.5 S -----------------
        if(Timer_Tick(3) )
            {
            Clear_Timer_Tick(3);
			LATDbits.LATD3 ^= 1;
		 
			}
        
        }
	
	} // main 000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000