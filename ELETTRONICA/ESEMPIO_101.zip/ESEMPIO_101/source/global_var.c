


unsigned int TickTimer;


unsigned short int Ing;
unsigned short int Ing_old;
unsigned short int Ing_FRL;
unsigned short int Ing_FRH;

 
/*
unsigned char Key_Stato;
unsigned char New_Key;
unsigned  char Key;
unsigned char AntiR;
unsigned short int TimeOutKey=100;
*/


unsigned short int ADC_CHA0;
unsigned short int ADC_CHA1;

