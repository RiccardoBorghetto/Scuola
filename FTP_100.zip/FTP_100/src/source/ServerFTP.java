package source;
import java.util.Timer;
import java.util.TimerTask;


public class ServerFTP {
   
    private MainForm FormA;
    private Seriale  seriale;

    // attributi privati  ( uso interno)
    private boolean ftpStart = false;
    private byte ftpState=0;
    private int ftpTimeout=0;
    private byte[] dati = new byte[64];
    private byte lenDati;
    
    
    
     // ------------costruttore -----------    
    public  ServerFTP(MainForm x,Seriale ser ) {
        FormA=x;
        seriale = ser;
        ftpState=0;
        Timer timer=new Timer();
        timer.schedule(new timerTask(), 100, 100);

     }

    class timerTask extends TimerTask{
        @Override
        public void run(){
        // inserire qui il codice da eseguire ad tick timer
        ftpTimeout ++;
        ftpFile();

        }
    }
    
    // ----------- Macchina a Stati per l'invio del file ----------    
    public void ftpFile()
        {
        switch(ftpState)    
            {
            // ------------- stato in attesa di START SERVER ----------
            case 0:
                if(ftpStart == false)
                    break;
                ftpState = 1;
                break;    
                
            // Stato di attesa che un client si colleghi
            case 1:
                if(seriale.rxInfoOK){
                
                
                
                }
                break;
                
                
                
                
                
                
                
                
                
                
                
                
            
           
    
    
    
    
    
    
    
    
    
    
}
}
}