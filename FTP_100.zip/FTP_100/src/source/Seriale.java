/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package source;
import jssc.*;

/**
 *
 * @author fabio
 */
public class Seriale {

    public boolean isIsOpen() {
        return isOpen;
    }
    

    
    private  static SerialPort uart1; 
    
    // attributi privati  ( uso interno)
    private boolean isOpen = false;
    private byte rxState=0;  
    private byte rxConta=0; 
    private byte rxLen=0; 
    private int rxCheck;    
    private byte[] rxBuff=new byte[256];
    
    // attributi  di  interfaccia 
    byte[] rxInfo=new byte[256];
    boolean rxInfoOK=false;
    byte rxLenInfo;
    
    private MainForm FormA;
    
    
    
    // ---------------------costruttore     
    public  Seriale(MainForm x) {
        FormA=x;
        rxState=0;
        rxInfoOK=false;
     
    }
    
   /**************************************************
      *   metodo per ricercare porte COM sul sisetma
      * 
      * @return 
      **************************************************/
    
    public String[] ricercaPorteCom(){
        return(SerialPortList.getPortNames());
           
    }    
      
  
    
    
/********************************************************************
     * 
     * Apertura Porta COM
     * @param NomeCom 
     ********************************************************************/
    
    public  void OpenCom(String NomeCom){
        // istanzia oggetto uart1 della classe "SerialPort"
        uart1=new SerialPort(NomeCom);
        try{
            // Apertura COM
            uart1.openPort();
            // Settaggio Parametri  di Comunicazione
            uart1.setParams(SerialPort.BAUDRATE_9600,
                            SerialPort.DATABITS_8,
                            SerialPort.STOPBITS_1,
                            SerialPort.PARITY_NONE
                            );
            // installa Listener su Evento di Ricezione 
            uart1.addEventListener(new PortReader(), SerialPort.MASK_RXCHAR);
            isOpen = true;
        }
        catch(SerialPortException ex) {System.out.println("Errore porta"+ex);
        }
    }
/******************************************************
 * 
 * 
 * 
 * @param b 
 ******************************************************/
   public  void TxByte(byte b){
       
       if(isOpen==false)
           return;
       
       try{
            uart1.writeByte(b);// STX
        }
        catch (SerialPortException ex) {
        }       
    }     
   /**
     * 
     * @param info
     * @param len 
     * 
     * --------------------------------------------------------------------------
     * Metodo per la trasmissione di un pacchetto  secondo il protocollo:
     *  STX |  Len | Info1 | ....| InfoN | Check | ETX
     * --------------------------------------------------------------------------
     * 
     * 
     */
     public  void TxPacchetto(byte info[], byte len){
        int i;
        int check;
        int check_L;
        int check_H;
        
        // calcola il check del pacchetto
        check=len;
        for(i=0;i<len;i++){
            check=check+info[i];
        }
        check_L=check&0x00FF;
        check_H=(check>>8)&0x00FF;
        try{
            uart1.writeByte((byte)2);// STX
            uart1.writeByte((byte)(len));
            for(i=0;i<len;i++)
                uart1.writeByte(info[i]);
            uart1.writeByte((byte)check_L);
          //  uart1.writeByte((byte)check_H);
            uart1.writeByte((byte)3);// ETX
        }
        catch (SerialPortException ex) {
        }
    }// end TxPacchetto   
    
    

/**
     * 
     * @param input
     * @param len 
     * 
     * -------------------------------------------------------------------------------
     * MACCHINA  A STATI PER LA RICEZIONIE DI PACCHETTI SECONDO IL PROTOCOLLO DEFINITO
     * ------------------------------------------------------------------------------
     *  input: vettore di byte contenente  i caratteri ricevuti dalla seriale
     *         
     *  output : rxPacc_OK -->  
     *           rxInfo ---->
     *           rxLen ---->
     *----------------------------------------------------------------------------- 
     */
    
    public  void RxPacchetto(byte input[], byte len){
        int i;  int k;   int temp;  
        
        for(i=0;i<len;i++)   // ciclo for per processare tutti i caratteri in input
            {  
            switch(rxState)    
            {
            // ------------- stato in attesa di ricevere STX ----------
            // se ricevo STX  allora azzera contatore e cambia stato 
            case 0:
                if(input[i]==(byte)2)
                    rxState=1;
                break;
            
            // stato per la ricezione di len   
            case 1:
                rxLen=(byte)input[i];
                rxState=2;
                rxConta=0; 
                break;
            
            // stato per la ricezione fino a tutta la info    
            case 2:
                rxBuff[rxConta++]=(byte)input[i];
                if(rxConta==rxLen)
                    rxState=3;
                break;
            // ------ ricezione check --------
            case 3:
                rxCheck=input[i];
                rxCheck&=0x00FF;
                rxState=4;
                break;         
        // ricezione di ETX e controllo correttezza pacchetto   
        case 4:
            if((byte)input[i]==(byte)3)
                {
                // controllo check
                temp=rxLen;
                for(k=0;k<rxConta;k++)
                    {temp=temp+rxBuff[k];}
                temp=temp&0x00FF;
                if(temp==rxCheck){
                    // se check OK estrae info e segnala ricezione pacchetto
                    System.arraycopy(rxBuff, 0, rxInfo, 0, rxConta);
                    rxLenInfo=rxConta;
                    rxInfoOK=true;
                    }
                }
            rxState=0;
            break;
                
            }// FINE SWITCH
        } // fine for sui caratteri ricevuti    
       } // END RxPacchetto 
    


    

 /**
     *  metodo da installare sull'evento di ricezione 
     * 
     * 
     * 
     */
    private  class PortReader implements SerialPortEventListener {
        @Override
        public void serialEvent(SerialPortEvent event) {
            int conta;
            int x;
            byte inBuff[]=new byte[256];
            if(event.isRXCHAR() && event.getEventValue() > 0) {
                try {
                    // lettura dei byte presenti nel buffer UART
                    conta=uart1.getInputBufferBytesCount();
                    inBuff=uart1.readBytes(conta);
                     
                    // stampa nella jTextArea ( in formato unsigned byte)
                    for(int j=0;j<conta;j++){
                        x=inBuff[j];
                        x&=0x00FF;
                        FormA.RxData.append(x+"\n");
                     }
                      
                   
                    RxPacchetto(inBuff, (byte)conta);
                    if(rxInfoOK)
                        {
                       // rxInfoOK=false; // azzera segnalazione
                        // stampa payload
                        FormA.RxPacc.append("\n RICEVUTO PACCHETTO\n");
                        for(int j=0;j<rxLenInfo;j++){
                            x=rxInfo[j];
                            x&=0x00FF;
                            FormA.RxPacc.append(x+"\n");
                        }
                     }
                    }
                catch (SerialPortException ex) {
                    System.out.println("Error rx from port: " + ex);
                    }
                }
            }
   
    } 
   
}// end class
