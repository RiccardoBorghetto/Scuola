/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package source;
import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author fabio
 */
public class UploadFile {

    public void setUploadStart(boolean uploadStart) {
        this.uploadStart = uploadStart;
    }

    private MainForm FormA;
    private Seriale  seriale;

    // attributi privati  ( uso interno)
    private boolean uploadStart = false;
    private byte uploadState=0;
    private int uploadTimeout=0;
    private byte[] dati = new byte[64];
    private byte lenDati;

   String nomeFile ="prova.txt"; 
    
    


    // ------------costruttore -----------    
    public  UploadFile(MainForm x,Seriale ser ) {
        FormA=x;
        seriale = ser;
        uploadState=0;
        Timer timer=new Timer();
        timer.schedule(new timerTask(), 100, 100);

     }

    class timerTask extends TimerTask{
        @Override
        public void run(){
        // inserire qui il codice da eseguire ad tick timer
        uploadTimeout ++;
        UploadFile();

        }
    }



    // ----------- Macchina a Stati per l'invio del file ----------    
    public void UploadFile()
        {
        switch(uploadState)    
            {
            // ------------- stato in attesa di START UPLOAD ----------
            case 0:
                if(uploadStart == false)
                    break;
                uploadState = 1;
                break;    
                
            // verifica se porta APERTA  e File  presente 
            case 1:
                if(seriale.isIsOpen() == false){
                    FormA.ReportUpload.append("Seriale NON Aperta");
                    uploadStart = false;
                    uploadState = 0;    
                }
                uploadState = 2;  
                break;
            
            // invio richiesta al Server FTP 
            case 2:
                dati[0] = 50;
                byte[] byteArray = nomeFile.getBytes();
                System.arraycopy(byteArray, 0, dati, 1, byteArray.length);
                seriale.rxInfoOK = false;
                seriale.TxPacchetto(dati,(byte) (byteArray.length+1) );
                uploadTimeout=0;
                uploadState = 3; 
                break;

            // attesa risposta dal Server FTP 
            case 3:
                if(seriale.rxInfoOK){
                    //analizzo pacchetto risposta
                    //per adesso mi accontento della risposta
                    FormA.ReportUpload.append("SERVER PRONTO");
                    //uploadStart = false;
                    //uploadState = 0;
                    //apertura file da inviare
                    uploadState = 4;
                    break;  
                    }
                if(uploadTimeout <10 )
                    break;
                FormA.ReportUpload.append("SERVER non Presente");
                uploadStart = false;
                uploadState = 0;
                break;  
                

             // lettura riga e invio pacchetto ( riga del file di testo)
            case 4:
                //lettura riga dal file
                //preparo payload 
                //ivoco trasmissione pacchetto
                uploadTimeout = 0;
                uploadState = 0;
                
               
                break;
            // attesa risposta dal Server 
                
            case 5:
                if(seriale.rxInfoOK){
                    //analizzo pacchetto risposta
                    //si trova su seriale .rxInfo
                    //se tutto ok allora controlla se ci sonon altre righe
                    //se ci sonon acora righe allora torna alla fase 4
                    //altrimanti passsa in fase 6
                    
                    
                    break;  
                    }
                if(uploadTimeout <10 )
                    break;
                FormA.ReportUpload.append("UPLOAD interrotto");
                uploadStart = false;
                uploadState = 0;
                break; 
               
                
            
            //invio comando di fine upload    
            case 6:
                 dati[0] = 52;
                 
                seriale.rxInfoOK = false;
                //seriale.TxPacchetto(dati,(byte) (byteArray.length+1) );
                uploadTimeout=0;
                uploadState = 7; 
                break;

            // attesa risposta dal Server FTP 
            case 7:
                if(seriale.rxInfoOK){
                    //analizzo pacchetto risposta
                    //per adesso mi accontento della risposta
                    FormA.ReportUpload.append("TRASFERIMENTO COMPLETATO");
                    uploadStart = false;
                    uploadState = 0;
                    break;  
                    }
                if(uploadTimeout <10 )
                    break;
                FormA.ReportUpload.append("SERVER non Presente");
                uploadStart = false;
                uploadState = 0;
                break;  
                
           }

        }

}





